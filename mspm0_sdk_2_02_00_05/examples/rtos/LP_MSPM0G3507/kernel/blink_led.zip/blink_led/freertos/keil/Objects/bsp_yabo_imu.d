./objects/bsp_yabo_imu.o: ..\..\bsp\bsp_yabo_IMU.c \
  ..\..\bsp\bsp_yabo_IMU.h C:\Keil_v5\ARM\ARMCLANG\include\stdint.h \
  ..\..\bsp\bsp_uart.h C:\Keil_v5\ARM\ARMCLANG\include\stdbool.h \
  C:\Keil_v5\ARM\ARMCLANG\include\stdarg.h \
  C:\Keil_v5\ARM\ARMCLANG\include\string.h
