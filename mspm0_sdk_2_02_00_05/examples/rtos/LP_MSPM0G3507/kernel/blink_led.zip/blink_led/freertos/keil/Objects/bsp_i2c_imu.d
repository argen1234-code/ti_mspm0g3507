./objects/bsp_i2c_imu.o: ..\..\bsp\bsp_i2c_imu.c ..\..\bsp\bsp_i2c_imu.h \
  C:\Keil_v5\ARM\ARMCLANG\include\stdint.h ..\..\bsp\bsp_i2c_hw.h \
  C:\Keil_v5\ARM\ARMCLANG\include\string.h
