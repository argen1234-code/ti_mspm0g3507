/*
 * 8 路循迹模块 — PORTB 单端口数字输入 + 黑线中心位置计算
 *
 * 引脚: PB17/18/19/21/22/23/25/26
 *
 * 数据流:
 *   红外对管阵列 ──→ 8 GPIO 数字输入 ──→ bsp_track_read() → uint8_t 位掩码
 *     └─ bsp_track_line_position() → 加权平均求中心位置
 *
 * 典型用途: PID 循迹, 黑线偏差量反馈给电机控制
 */

#include "ti_msp_dl_config.h"
#include "bsp_track.h"

static const uint32_t track_iomux[] = {
    TRACK1_IOMUX, TRACK2_IOMUX, TRACK3_IOMUX, TRACK4_IOMUX,
    TRACK5_IOMUX, TRACK6_IOMUX, TRACK7_IOMUX, TRACK8_IOMUX,
};

static const uint32_t track_pin[] = {
    TRACK1_PIN, TRACK2_PIN, TRACK3_PIN, TRACK4_PIN,
    TRACK5_PIN, TRACK6_PIN, TRACK7_PIN, TRACK8_PIN,
};

/* 位置权重: 左→右, 单位 0.1 通道, 中心为 0 */
static const int16_t track_weight[] = {
    -350, -250, -150, -50, 50, 150, 250, 350,
};

void bsp_track_init(void)
{
    for (int i = 0; i < 8; i++) {
        DL_GPIO_initDigitalInputFeatures(track_iomux[i],
            DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
            DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);
    }
}

uint8_t bsp_track_read(void)
{
    uint32_t raw = DL_GPIO_readPins(TRACK_PORT, TRACK_ALL_PINS);
    uint8_t result = 0;

    for (int i = 0; i < 8; i++) {
        if (!(raw & track_pin[i])) {
            result |= (1 << i);
        }
    }
    /* result: 1=黑线(LOW), 0=白底(HIGH) */
    return result;
}

bool bsp_track_get_channel(uint8_t ch)
{
    if (ch < 1 || ch > 8) return false;
    /* 取反: LOW=黑线=true, HIGH=白底=false */
    return (DL_GPIO_readPins(TRACK_PORT, track_pin[ch - 1]) == 0);
}

int16_t bsp_track_line_position(bool *valid)
{
    uint8_t data = bsp_track_read();
    int32_t sum = 0;
    int32_t count = 0;

    for (int i = 0; i < 8; i++) {
        if (data & (1 << i)) {
            sum += track_weight[i];
            count++;
        }
    }

    /* 全白或全黑 → 无效 */
    if (count == 0 || count == 8) {
        if (valid) *valid = false;
        return 0;
    }

    if (valid) *valid = true;
    return (int16_t)(sum / count);
}
