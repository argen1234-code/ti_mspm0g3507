/*
 * SPI 主机驱动 — SPI0 + SPI1 初始化 + 预留传输函数
 *
 * 引脚:
 *   SPI0: PA6(SCLK) + PA5(PICO) + PA4(POCI) + PA2(CS0)
 *         PINCM11/10/9/7, 全部在 GPIOA
 *   SPI1: PB16(SCLK) + PB15(PICO) + PB14(POCI)
 *         PINCM33/32/31, 全部在 GPIOB
 *
 * 时钟:
 *   BUSCLK = 80MHz, 目标 SCLK = 1MHz
 *   SPI0: 80MHz / 80 = 1MHz (CPSDVSR 预分频)
 *   SPI1: 同 SPI0
 *
 * 默认格式:
 *   Motorola 4-Wire, CPOL=0, CPHA=0, MSB first, 8-bit 帧
 *   CS: SPI0 用硬件 CS0, SPI1 用软件 GPIO 片选
 */

#include "ti_msp_dl_config.h"
#include "bsp_spi.h"

/* ---- SPI0 初始化 ---- */
static void bsp_spi0_init(void)
{
    /* ---- 电源 + 复位 ---- */
    DL_SPI_enablePower(BSP_SPI0_INST);
    DL_SPI_reset(BSP_SPI0_INST);

    /* ---- GPIO 配置为 SPI 外设功能 ---- */
    DL_GPIO_initPeripheralFunction(BSP_SPI0_SCLK_IOMUX,
        IOMUX_PINCM11_PF_SPI0_SCLK);
    DL_GPIO_initPeripheralFunction(BSP_SPI0_PICO_IOMUX,
        IOMUX_PINCM10_PF_SPI0_PICO);
    DL_GPIO_initPeripheralFunction(BSP_SPI0_POCI_IOMUX,
        IOMUX_PINCM9_PF_SPI0_POCI);
    DL_GPIO_initPeripheralFunction(BSP_SPI0_CS0_IOMUX,
        IOMUX_PINCM7_PF_SPI0_CS0);

    /* ---- 时钟: BUSCLK, /2 → 40MHz bit clock base ---- */
    DL_SPI_ClockConfig clk_cfg = {
        .clockSel    = DL_SPI_CLOCK_BUSCLK,
        .divideRatio = DL_SPI_CLOCK_DIVIDE_RATIO_2,
    };
    DL_SPI_setClockConfig(BSP_SPI0_INST, &clk_cfg);

    /* ---- SPI 控制器配置: Motorola 4-Wire, CPOL=0, CPHA=0, 8-bit ---- */
    DL_SPI_Config spi_cfg = {
        .mode            = DL_SPI_MODE_CONTROLLER,
        .frameFormat     = DL_SPI_FRAME_FORMAT_MOTO4_POL0_PHA0,
        .parity          = DL_SPI_PARITY_NONE,
        .dataSize        = DL_SPI_DATA_SIZE_8,
        .bitOrder        = DL_SPI_BIT_ORDER_MSB_FIRST,
        .chipSelectPin   = DL_SPI_CHIP_SELECT_0,
    };
    DL_SPI_init(BSP_SPI0_INST, &spi_cfg);

    /*
     * 设置 SCLK = 1MHz
     *   bitClk = 80MHz / 2 = 40MHz (from divideRatio)
     *   SCLK = bitClk / (1 + SCR)
     *   SCR = 39 → 40MHz / 40 = 1MHz
     */
    DL_SPI_setBitRateSerialClockDivider(BSP_SPI0_INST, 39);

    DL_SPI_enable(BSP_SPI0_INST);

    /* 中断暂不使能, 上层按需开启 */
}

/* ---- SPI1 初始化 ---- */
static void bsp_spi1_init(void)
{
    DL_SPI_enablePower(BSP_SPI1_INST);
    DL_SPI_reset(BSP_SPI1_INST);

    /* ---- GPIO 配置为 SPI1 外设功能 ---- */
    DL_GPIO_initPeripheralFunction(BSP_SPI1_SCLK_IOMUX,
        IOMUX_PINCM33_PF_SPI1_SCLK);
    DL_GPIO_initPeripheralFunction(BSP_SPI1_PICO_IOMUX,
        IOMUX_PINCM32_PF_SPI1_PICO);
    DL_GPIO_initPeripheralFunction(BSP_SPI1_POCI_IOMUX,
        IOMUX_PINCM31_PF_SPI1_POCI);

    /* ---- 时钟 + 控制器配置 ---- */
    DL_SPI_ClockConfig clk_cfg = {
        .clockSel    = DL_SPI_CLOCK_BUSCLK,
        .divideRatio = DL_SPI_CLOCK_DIVIDE_RATIO_2,
    };
    DL_SPI_setClockConfig(BSP_SPI1_INST, &clk_cfg);

    DL_SPI_Config spi_cfg = {
        .mode            = DL_SPI_MODE_CONTROLLER,
        .frameFormat     = DL_SPI_FRAME_FORMAT_MOTO4_POL0_PHA0,
        .parity          = DL_SPI_PARITY_NONE,
        .dataSize        = DL_SPI_DATA_SIZE_8,
        .bitOrder        = DL_SPI_BIT_ORDER_MSB_FIRST,
        .chipSelectPin   = DL_SPI_CHIP_SELECT_NONE,  /* 软件 CS */
    };
    DL_SPI_init(BSP_SPI1_INST, &spi_cfg);

    DL_SPI_setBitRateSerialClockDivider(BSP_SPI1_INST, 39);
    DL_SPI_enable(BSP_SPI1_INST);
}

void bsp_spi_init(void)
{
    bsp_spi0_init();
    bsp_spi1_init();
}

/* ================================================================
 *  以下为预留 API, 待实现
 * ================================================================ */

bool bsp_spi0_transfer(const uint8_t *tx, uint8_t *rx, uint8_t len)
{
    (void)tx; (void)rx; (void)len;
    /*
     * TODO:
     *   1. 置 CS0 为低 (或使用硬件 CS, 自动)
     *   2. 填充 TX FIFO → 等待 RX FIFO → 读取数据
     *   3. 置 CS0 为高
     */
    return false;
}

bool bsp_spi1_transfer(const uint8_t *tx, uint8_t *rx, uint8_t len, uint32_t cs_pin)
{
    (void)tx; (void)rx; (void)len; (void)cs_pin;
    /* TODO: 软件 CS 控制 + SPI 传输 */
    return false;
}

void bsp_spi0_set_freq(uint32_t freq_hz)
{
    (void)freq_hz;
    /* TODO: DL_SPI_setBitRate 动态调整 */
}

void bsp_spi1_set_freq(uint32_t freq_hz)
{
    (void)freq_hz;
}
