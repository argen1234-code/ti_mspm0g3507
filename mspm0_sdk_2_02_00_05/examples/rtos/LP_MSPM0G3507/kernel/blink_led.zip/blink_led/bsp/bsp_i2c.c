/*
 * I2C1 主机驱动 — 初始化 + 预留传输函数
 *
 * 引脚:
 *   SCL: PA29 (PINCM4, IOMUX I2C1_SCL)
 *   SDA: PA30 (PINCM5, IOMUX I2C1_SDA)
 *
 * 时钟:
 *   BUSCLK = 80MHz → CLK_PRD = 12.5ns
 *   SCL_PERIOD = (1 + TPR) * (SCL_LP + SCL_HP) * CLK_PRD
 *              = (1 + 79) * (6 + 4) * 12.5ns = 10000ns = 100kHz (标准模式)
 */

#include "ti_msp_dl_config.h"
#include "bsp_i2c.h"

void bsp_i2c_init(void)
{
    /* ---- 电源 + 复位 ---- */
    DL_I2C_enablePower(BSP_I2C_INST);
    DL_I2C_reset(BSP_I2C_INST);

    /* ---- GPIO 配置为 I2C 开漏外设功能 ---- */
    DL_GPIO_initPeripheralFunction(BSP_I2C_SCL_IOMUX,
        IOMUX_PINCM4_PF_I2C1_SCL);
    DL_GPIO_initPeripheralFunction(BSP_I2C_SDA_IOMUX,
        IOMUX_PINCM5_PF_I2C1_SDA);

    /* ---- 时钟: BUSCLK ---- */
    DL_I2C_ClockConfig clk_cfg = {
        .clockSel    = DL_I2C_CLOCK_BUSCLK,
        .divideRatio = DL_I2C_CLOCK_DIVIDE_1,
    };
    DL_I2C_setClockConfig(BSP_I2C_INST, &clk_cfg);

    /* ---- 控制器模式: 100kHz 标准模式 ---- */
    DL_I2C_setTimerPeriod(BSP_I2C_INST, 79);  /* 100kHz @ 80MHz BUSCLK */
    DL_I2C_setControllerAddressingMode(BSP_I2C_INST,
        DL_I2C_CONTROLLER_ADDRESSING_MODE_7_BIT);

    /*
     * 使能模拟毛刺滤波器 (50ns 脉冲抑制, I2C 规范要求)
     * 使能起始条件生成 (写 TX FIFO 后自动产生 START)
     */
    DL_I2C_enableAnalogGlitchFilter(BSP_I2C_INST);
    DL_I2C_enableStartCondition(BSP_I2C_INST);
    DL_I2C_enableController(BSP_I2C_INST);

    /* 中断暂不使能, 上层按需调用 NVIC_EnableIRQ(BSP_I2C_INT_IRQN) */
}

/* ================================================================
 *  以下为预留 API, 待实现
 * ================================================================ */

bool bsp_i2c_write(uint8_t addr, const uint8_t *data, uint8_t len)
{
    (void)addr; (void)data; (void)len;
    /* TODO: 填充 TX FIFO → 设置目标地址 → 使能 START/STOP → 等待完成 */
    return false;
}

bool bsp_i2c_read(uint8_t addr, uint8_t *data, uint8_t len)
{
    (void)addr; (void)data; (void)len;
    /* TODO: 设置读方向 → 设置目标地址 → 使能 START → 等待 RX FIFO → STOP */
    return false;
}

bool bsp_i2c_write_reg(uint8_t addr, uint8_t reg, uint8_t value)
{
    uint8_t buf[2] = {reg, value};
    return bsp_i2c_write(addr, buf, 2);
}

bool bsp_i2c_read_reg(uint8_t addr, uint8_t reg, uint8_t *value)
{
    (void)addr; (void)reg; (void)value;
    /* TODO: write(reg) → RESTART → read(1) */
    return false;
}

void bsp_i2c_scan(void)
{
    /* TODO: 遍历 0x08~0x77, 对每个地址发送 START+地址+STOP, 记录 ACK */
}
