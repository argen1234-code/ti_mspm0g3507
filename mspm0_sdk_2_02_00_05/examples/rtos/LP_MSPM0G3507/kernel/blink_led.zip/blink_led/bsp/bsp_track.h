/*
 * 8 路循迹模块 — 数字输入 (PORTB 单端口读取)
 *
 * 引脚 (全部 PORTB):
 *   TRACK1: PB17 (PINCM43)    TRACK5: PB22 (PINCM50)
 *   TRACK2: PB18 (PINCM44)    TRACK6: PB23 (PINCM51)
 *   TRACK3: PB19 (PINCM45)    TRACK7: PB25 (PINCM56)
 *   TRACK4: PB21 (PINCM49)    TRACK8: PB26 (PINCM57)
 *
 * 传感器: 红外对管 (ITR20001 或同类), 黑线吸收 / 白底反射
 *   有反射(白) → 输出 HIGH, 无反射(黑) → 输出 LOW
 *   循迹时跟踪黑线, API 内部自动取反: 黑=1, 白=0
 */

#ifndef BSP_TRACK_H
#define BSP_TRACK_H

#include <stdint.h>
#include <stdbool.h>

/* ---- 引脚端口 ---- */
#define TRACK_PORT          GPIOB

/* ---- 引脚位 ---- */
#define TRACK1_PIN          DL_GPIO_PIN_17
#define TRACK2_PIN          DL_GPIO_PIN_18
#define TRACK3_PIN          DL_GPIO_PIN_19
#define TRACK4_PIN          DL_GPIO_PIN_21
#define TRACK5_PIN          DL_GPIO_PIN_22
#define TRACK6_PIN          DL_GPIO_PIN_23
#define TRACK7_PIN          DL_GPIO_PIN_25
#define TRACK8_PIN          DL_GPIO_PIN_26

/* ---- IOMUX ---- */
#define TRACK1_IOMUX        (IOMUX_PINCM43)
#define TRACK2_IOMUX        (IOMUX_PINCM44)
#define TRACK3_IOMUX        (IOMUX_PINCM45)
#define TRACK4_IOMUX        (IOMUX_PINCM49)
#define TRACK5_IOMUX        (IOMUX_PINCM50)
#define TRACK6_IOMUX        (IOMUX_PINCM51)
#define TRACK7_IOMUX        (IOMUX_PINCM56)
#define TRACK8_IOMUX        (IOMUX_PINCM57)

/* ---- 通道位掩码 ---- */
#define TRACK_CH1           0x01
#define TRACK_CH2           0x02
#define TRACK_CH3           0x04
#define TRACK_CH4           0x08
#define TRACK_CH5           0x10
#define TRACK_CH6           0x20
#define TRACK_CH7           0x40
#define TRACK_CH8           0x80

/* ---- 全部引脚掩码 ---- */
#define TRACK_ALL_PINS      (TRACK1_PIN | TRACK2_PIN | TRACK3_PIN | TRACK4_PIN | \
                             TRACK5_PIN | TRACK6_PIN | TRACK7_PIN | TRACK8_PIN)

/* ---- API ---- */

/*
 * bsp_track_init — 初始化 8 路循迹引脚为数字输入 + 上拉
 *   传感器默认输出 HIGH (白底), 黑线时拉 LOW
 */
void bsp_track_init(void);

/*
 * bsp_track_read — 读取 8 路循迹值 (取反后)
 *   返回 8-bit 位掩码, bit0=TRACK1 ... bit7=TRACK8
 *   1 = 黑线 (LOW), 0 = 白底 (HIGH)
 */
uint8_t bsp_track_read(void);

/*
 * bsp_track_get_channel — 读取单路
 *   ch: 通道号 1~8
 */
bool bsp_track_get_channel(uint8_t ch);

/*
 * bsp_track_line_position — 计算黑线中心位置 (加权平均)
 *   返回值: -1000~+1000 (左→右), 单位 0.1 通道
 *   0 = 正中间, 负值偏左, 正值偏右
 *   全白或全黑时返回 0 并设置 *valid = false
 */
int16_t bsp_track_line_position(bool *valid);

#endif
