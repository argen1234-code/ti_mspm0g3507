/*
 * 蓝牙透传通信接口 — 预留
 *
 * 数据流 (未来):
 *   手机App ──蓝牙RF──→ 蓝牙模块(HC-05/JDY-31) ──UART3──→ MSPM0G3507
 *     ├─ RX: 手机 → 蓝牙模块 → UART3_RX(PB13) → bt_rx_buf → bsp_bluetooth_read()
 *     └─ TX: bsp_bluetooth_send() → DL_UART_Main_transmitData(UART_3_INST)
 *               → UART3_TX(PB12) → 蓝牙模块 → 手机
 *
 * 硬件: UART3 (PB12-TX/PB13-RX), 115200-8-N-1, 需外接蓝牙透传模块
 *       蓝牙模块需事先通过 AT 命令配置:
 *         AT+NAME=MSPM0_BT      设备名称
 *         AT+UART=115200,0,0    波特率/停止位/校验
 *         AT+ROLE=0             从机模式
 *
 * 当前状态: UART3 已在 bsp_uart_bt_init() 中初始化为接收模式,
 *          本文件仅提供接口桩函数, 等待上层蓝牙协议栈实现.
 *
 * 引脚: PB12 (UART3_TX) / PB13 (UART3_RX) — 由 SysConfig 配置
 */

#ifndef BSP_BLUETOOTH_H
#define BSP_BLUETOOTH_H

#include <stdint.h>
#include <stdbool.h>
#include "ti_msp_dl_config.h"

/* ---- 蓝牙消息结构 (预留) ---- */
typedef struct {
    uint8_t  data[256];     /* 透传数据负载 */
    uint16_t len;           /* 有效数据长度 */
} bsp_bt_msg_t;

/* ---- 外部接口 (当前均为空实现) ---- */

void bsp_bluetooth_init(void);                          /* 蓝牙模块初始化 (AT配置/参数设置) */
void bsp_bluetooth_send(const uint8_t *data, uint16_t len); /* 发送透传数据到手机 */
bool bsp_bluetooth_read(uint8_t *data, uint16_t *len);  /* 读取透传数据 (非阻塞, 从bt_rx_buf取) */

#endif
