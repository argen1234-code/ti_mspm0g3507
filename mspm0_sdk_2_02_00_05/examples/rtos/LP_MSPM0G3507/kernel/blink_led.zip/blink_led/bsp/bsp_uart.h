#ifndef BSP_UART_H
#define BSP_UART_H

#include <stdint.h>
#include <stdbool.h>
#include <stdarg.h>

/*
 * 四串口驱动 — 环形缓冲 + ISR 数据流接口
 *
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║                        全4路UART总览                                  ║
 * ╠════════╦══════════════╦══════════════╦═══════════╦═══════════════════╣
 * ║  外设  ║   引脚配置    ║   数据流向    ║  波特率   ║     用途          ║
 * ╠════════╬══════════════╬══════════════╬═══════════╬═══════════════════╣
 * ║ UART0  ║ PA10-TX      ║ TX: printf   ║  115200   ║ 调试输出/命令接收  ║
 * ║        ║ PA11-RX      ║ RX: 上位机   ║           ║                   ║
 * ╠════════╬══════════════╬══════════════╬═══════════╬═══════════════════╣
 * ║ UART1  ║ PB4-TX       ║ TX: 未使用   ║  115200   ║ IMU 姿态传感器     ║
 * ║        ║ PB5-RX       ║ RX: IMU→MCU  ║           ║ (WitMotion协议)   ║
 * ╠════════╬══════════════╬══════════════╬═══════════╬═══════════════════╣
 * ║ UART2  ║ PA21-TX      ║ TX: 待实现   ║  115200   ║ 摄像头通信 (预留)  ║
 * ║        ║ PA22-RX      ║ RX: 摄像头   ║           ║                   ║
 * ╠════════╬══════════════╬══════════════╬═══════════╬═══════════════════╣
 * ║ UART3  ║ PB12-TX      ║ TX: 待实现   ║  115200   ║ 蓝牙透传 (预留)   ║
 * ║        ║ PB13-RX      ║ RX: 蓝牙模块 ║           ║                   ║
 * ╚════════╧══════════════╧══════════════╧═══════════╧═══════════════════╝
 *
 * ┌────────────────── 数据流架构 (ISR → 环形缓冲 → Task) ──────────────────┐
 * │                                                                       │
 * │  UART0_RX  ──→ UART0_IRQHandler ──→ rx_buf[256]      ──→ uart_rxbuf_pop()    ──→ 命令解析Task │
 * │  UART1_RX  ──→ UART1_IRQHandler ──→ imu_rx_buf[256]  ──→ uart_imu_rxbuf_pop() ──→ IMU解析器    │
 * │  UART2_RX  ──→ UART2_IRQHandler ──→ cam_rx_buf[256]  ──→ bsp_uart_cam_rxbuf_pop() ──→ 摄像头解析器 │
 * │  UART3_RX  ──→ UART3_IRQHandler ──→ bt_rx_buf[256]   ──→ bsp_uart_bt_rxbuf_pop() ──→ 蓝牙协议栈  │
 * │                                                                       │
 * │  所有TX均走: debug_print() ──→ uart_putc() ──→ UART0 TX ──→ 上位机     │
 * │  (UART1/UART2/UART3的TX由各自上层直接调用DL_UART_Main_transmitData)      │
 * │                                                                       │
 * └───────────────────────────────────────────────────────────────────────┘
 *
 * 环形缓冲规则 (ISR生产者 / Task消费者):
 *   - head (ISR写入位置) == tail (Task读取位置) → 缓冲区空
 *   - (head + 1) % BUF_SIZE == tail             → 缓冲区满, 丢弃新字节
 *   - ISR 在中断上下文中执行, 仅做 push 操作
 *   - Task 在 FreeRTOS 上下文中执行, 仅做 pop 操作
 *
 * SysConfig 回环模式注意:
 *   SysConfig 生成的 UARTx_init() 默认启用 loopback mode,
 *   导致 RX 仅能接收自身 TX 发出去的数据, 外部设备数据被忽略.
 *   每个 bsp_uart_*_init() 函数在运行时通过 changeConfig → disableLoopback
 *   → 重配FIFO → enable 这一流程来解决此问题.
 */

void bsp_uart_init(void);           /* UART0 调试串口 (PA10-TX/PA11-RX): printf输出 + 上位机命令接收 */
void bsp_uart_imu_init(void);       /* UART1 IMU串口 (PB4-TX/PB5-RX): WitMotion姿态传感器, 单向接收 */
void bsp_uart_cam_init(void);       /* UART2 摄像头串口 (PA21-TX/PA22-RX): 预留摄像头通信, 反回环 */
void bsp_uart_bt_init(void);        /* UART3 蓝牙串口 (PB12-TX/PB13-RX): 预留蓝牙透传, 反回环 */
void bsp_uart_send_byte(uint8_t ch);
void bsp_uart_send_str(const char *str);

/*
 * debug_print — 轻量级格式化打印 (纯栈操作, 零堆分配)
 *   支持: %d %ld %u %lu %c %s %x %X
 *   不支持: %f
 *   比标准 printf 节省 ~8KB ROM, 避免 MicroLIB 堆碎片
 *   输出通道: UART0 TX (PA10)
 */
void debug_print(const char *fmt, ...);

/* UART0 环形缓冲: ISR→命令解析Task
 *   数据来源: 上位机串口助手发来的调试命令
 *   消费方:   app层命令解析 (暂未实现)
 *   返回值:   true=成功取出一个字节, false=缓冲区空
 */
bool uart_rxbuf_pop(uint8_t *byte);

/* UART1 环形缓冲: ISR→IMU解析器
 *   数据来源: IMU模块(WitMotion)每秒约输出200帧, 帧长17~23字节
 *   消费方:   imu_yabo_process() → chassis_move.imu
 *   缓冲区大小: 256字节 (约可缓冲10~15帧, 覆盖约50~75ms)
 *   返回值:   true=成功取出一个字节, false=缓冲区空
 */
bool uart_imu_rxbuf_pop(uint8_t *byte);

/* UART2 环形缓冲: ISR→摄像头解析器
 *   数据来源: 摄像头模块 (协议未定)
 *   消费方:   未来 bsp_cam 模块
 *   缓冲区大小: 256字节
 *   返回值:   true=成功取出一个字节, false=缓冲区空
 */
bool bsp_uart_cam_rxbuf_pop(uint8_t *byte);

/* UART3 环形缓冲: ISR→蓝牙协议栈
 *   数据来源: 蓝牙透传模块 (如 HC-05/JDY-31, 典型波特率115200)
 *     蓝牙模块通常工作在"透传模式"(Serial Port Profile):
 *       - 手机App → 蓝牙RF → 蓝牙模块 → UART3_RX → bt_rx_buf → App协议处理
 *       - App协议处理 → DL_UART_Main_transmitData(UART_3_INST) → UART3_TX → 蓝牙模块 → 手机App
 *     收发均为双向, TX暂未封装统一函数, 由上层直接调用TI DriverLib API
 *   消费方:   未来蓝牙协议栈 (如数据透传、远程控制指令)
 *   缓冲区大小: 256字节 (蓝牙透传数据量通常较小, 256字节足够缓冲若干短帧)
 *   返回值:   true=成功取出一个字节, false=缓冲区空
 */
bool bsp_uart_bt_rxbuf_pop(uint8_t *byte);

#endif
