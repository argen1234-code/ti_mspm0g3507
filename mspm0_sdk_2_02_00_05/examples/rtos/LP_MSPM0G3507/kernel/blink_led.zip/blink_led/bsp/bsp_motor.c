/*
 * 四路直流电机驱动 — 双 TB6612 H桥
 *
 * TB6612 #1 (在用):
 *   数据流向: chassis_send_cmd() → bsp_motor_set_pwm(pwmA, pwmB)
 *     ├─ GPIO 方向控制
 *     │   Motor A: PA15(AIN2) / PA14(AIN1)
 *     │   Motor B: PA16(BIN2) / PA17(BIN1)
 *     │   pwm>0 → AIN2/BIN2=HIGH, AIN1/BIN1=LOW (正转)
 *     │   pwm<0 → AIN1/BIN1=HIGH, AIN2/BIN2=LOW (反转)
 *     └─ TIMA1 PWM (10kHz, 边沿对齐)
 *         Motor A: CCP0 (PB2), Motor B: CCP1 (PB3)

 * TB6612 #2 (预留, 已初始化):
 *   Motor C: PA9(C_AIN1)/PA19(C_AIN2) 方向 + PA3(TIMG7 CCP0) PWM
 *   Motor D: PA20(D_BIN1)/PB1(D_BIN2) 方向 + PA23(TIMG8 CCP0) PWM
 *   STBY: PB27 (共用使能, 高有效)
 *
 * 遗留函数 (当前未使用): bsp_motor_velocity_A/B (自带速度环, 已被 PID.c 替代)
 */

#include "ti_msp_dl_config.h"
#include "bsp_motor.h"
#include "bsp_board.h"

#define PWM_MAX  7999
#define PWM_MIN -7999

/* ---- TB6612 #2 方向引脚 ---- */
/* Motor C: AIN1=PA9(PINCM20), AIN2=PA19(PINCM41) */
#define MOTOR_C_AIN1_PORT    GPIOA
#define MOTOR_C_AIN1_PIN     DL_GPIO_PIN_9
#define MOTOR_C_AIN1_IOMUX   (IOMUX_PINCM20)
#define MOTOR_C_AIN2_PORT    GPIOA
#define MOTOR_C_AIN2_PIN     DL_GPIO_PIN_19
#define MOTOR_C_AIN2_IOMUX   (IOMUX_PINCM41)

/* Motor D: BIN1=PA20(PINCM42), BIN2=PB1(PINCM13) */
#define MOTOR_D_BIN1_PORT    GPIOA
#define MOTOR_D_BIN1_PIN     DL_GPIO_PIN_20
#define MOTOR_D_BIN1_IOMUX   (IOMUX_PINCM42)
#define MOTOR_D_BIN2_PORT    GPIOB
#define MOTOR_D_BIN2_PIN     DL_GPIO_PIN_1
#define MOTOR_D_BIN2_IOMUX   (IOMUX_PINCM13)

/* STBY = PB27 (PINCM58), 双路共用使能, 高有效 */
#define MOTOR_CD_STBY_PORT   GPIOB
#define MOTOR_CD_STBY_PIN    DL_GPIO_PIN_27
#define MOTOR_CD_STBY_IOMUX  (IOMUX_PINCM58)

/* ---- Motor C: PA3 (PINCM8) → TIMG7 CCP0 ---- */
#define MOTOR_C_PORT       GPIOA
#define MOTOR_C_PIN        DL_GPIO_PIN_3
#define MOTOR_C_IOMUX      (IOMUX_PINCM8)
#define MOTOR_C_TIMER      TIMG7
#define MOTOR_C_CCP_IDX    DL_TIMER_CC_0_INDEX

/* ---- Motor D: PA23 (PINCM53) → TIMG8 CCP0 ---- */
#define MOTOR_D_PORT       GPIOA
#define MOTOR_D_PIN        DL_GPIO_PIN_23
#define MOTOR_D_IOMUX      (IOMUX_PINCM53)
#define MOTOR_D_TIMER      TIMG8
#define MOTOR_D_CCP_IDX    DL_TIMER_CC_0_INDEX

static float Velcity_Kp = 2.6f;
static float Velcity_Ki = 1.3f;
static float ControlVelocityA = 0;
static float ControlVelocityB = 0;
static int32_t Last_biasA = 0;
static int32_t Last_biasB = 0;

int32_t bsp_motor_limit_pwm(int32_t value, int32_t low, int32_t high)
{
    if (value > high) return high;
    if (value < low)  return low;
    return value;
}

void bsp_motor_set_pwm(int32_t pwmA, int32_t pwmB)
{
    /* Motor A direction (AIN1=PA14, AIN2=PA15) */
    if (pwmA > 0) {
        DL_GPIO_setPins(AIN_PORT, AIN_AIN2_PIN);
        DL_GPIO_clearPins(AIN_PORT, AIN_AIN1_PIN);
    } else {
        DL_GPIO_setPins(AIN_PORT, AIN_AIN1_PIN);
        DL_GPIO_clearPins(AIN_PORT, AIN_AIN2_PIN);
    }

    /* Motor B direction (BIN1=PA16, BIN2=PA17) */
    if (pwmB > 0) {
        DL_GPIO_setPins(BIN_PORT, BIN_BIN2_PIN);
        DL_GPIO_clearPins(BIN_PORT, BIN_BIN1_PIN);
    } else {
        DL_GPIO_setPins(BIN_PORT, BIN_BIN1_PIN);
        DL_GPIO_clearPins(BIN_PORT, BIN_BIN2_PIN);
    }

    DL_Timer_setCaptureCompareValue(PWM_0_INST, ABS(pwmA), GPIO_PWM_0_C0_IDX);
    DL_Timer_setCaptureCompareValue(PWM_0_INST, ABS(pwmB), GPIO_PWM_0_C1_IDX);
}

/*
 * bsp_motor_init_cd — 初始化 TB6612 #2 (Motor C/D + STBY)
 *
 *   GPIO 方向: C_AIN1=PA9, C_AIN2=PA19, D_BIN1=PA20, D_BIN2=PB1
 *   STBY: PB27 (共用使能, 初始化后拉高)
 *   PWM: Motor C → TIMG7 CCP0 (PA3), Motor D → TIMG8 CCP0 (PA23)
 *
 *   参数: 10kHz 边沿对齐, 分辨率 7999, 初始占空比 0.
 *   方向引脚全部拉低, 初始刹车态.
 *
 *   调用链: chassis_init() → bsp_motor_init_cd()
 */
void bsp_motor_init_cd(void)
{
    DL_Timer_PWMConfig pwm_cfg = {
        .pwmMode           = DL_TIMER_PWM_MODE_EDGE_ALIGN_UP,
        .period            = PWM_MAX,
        .isTimerWithFourCC = false,
        .startTimer        = DL_TIMER_STOP,
    };
    DL_Timer_ClockConfig clk_cfg = {
        .clockSel    = DL_TIMER_CLOCK_BUSCLK,
        .divideRatio = DL_TIMER_CLOCK_DIVIDE_1,
        .prescale    = 0,
    };

    /* ---- 方向 GPIO 初始化 (全输出低, 刹车态) ---- */
    DL_GPIO_initDigitalOutput(MOTOR_C_AIN1_IOMUX);
    DL_GPIO_initDigitalOutput(MOTOR_C_AIN2_IOMUX);
    DL_GPIO_initDigitalOutput(MOTOR_D_BIN1_IOMUX);
    DL_GPIO_initDigitalOutput(MOTOR_D_BIN2_IOMUX);

    DL_GPIO_clearPins(MOTOR_C_AIN1_PORT, MOTOR_C_AIN1_PIN);
    DL_GPIO_clearPins(MOTOR_C_AIN2_PORT, MOTOR_C_AIN2_PIN);
    DL_GPIO_clearPins(MOTOR_D_BIN1_PORT, MOTOR_D_BIN1_PIN);
    DL_GPIO_clearPins(MOTOR_D_BIN2_PORT, MOTOR_D_BIN2_PIN);

    DL_GPIO_enableOutput(MOTOR_C_AIN1_PORT, MOTOR_C_AIN1_PIN);
    DL_GPIO_enableOutput(MOTOR_C_AIN2_PORT, MOTOR_C_AIN2_PIN);
    DL_GPIO_enableOutput(MOTOR_D_BIN1_PORT, MOTOR_D_BIN1_PIN);
    DL_GPIO_enableOutput(MOTOR_D_BIN2_PORT, MOTOR_D_BIN2_PIN);

    /* ---- STBY = PB27, 输出高 (使能) ---- */
    DL_GPIO_initDigitalOutput(MOTOR_CD_STBY_IOMUX);
    DL_GPIO_setPins(MOTOR_CD_STBY_PORT, MOTOR_CD_STBY_PIN);
    DL_GPIO_enableOutput(MOTOR_CD_STBY_PORT, MOTOR_CD_STBY_PIN);

    /* ---- Motor C PWM: TIMG7 → PA3 ---- */
    DL_Timer_reset(MOTOR_C_TIMER);
    DL_Timer_enablePower(MOTOR_C_TIMER);
    delay_cycles(POWER_STARTUP_DELAY);

    DL_GPIO_initPeripheralOutputFunction(MOTOR_C_IOMUX,
        IOMUX_PINCM8_PF_TIMG7_CCP0);
    DL_GPIO_enableOutput(MOTOR_C_PORT, MOTOR_C_PIN);

    DL_Timer_setClockConfig(MOTOR_C_TIMER, &clk_cfg);
    DL_TimerG_initPWMMode(MOTOR_C_TIMER, &pwm_cfg);

    DL_Timer_setCaptureCompareOutCtl(MOTOR_C_TIMER,
        DL_TIMER_CC_OCTL_INIT_VAL_LOW,
        DL_TIMER_CC_OCTL_INV_OUT_DISABLED,
        DL_TIMER_CC_OCTL_SRC_FUNCVAL, MOTOR_C_CCP_IDX);
    DL_Timer_setCaptCompUpdateMethod(MOTOR_C_TIMER,
        DL_TIMER_CC_UPDATE_METHOD_IMMEDIATE, MOTOR_C_CCP_IDX);
    DL_Timer_setCaptureCompareValue(MOTOR_C_TIMER, 0, MOTOR_C_CCP_IDX);

    DL_Timer_enableClock(MOTOR_C_TIMER);
    DL_Timer_setCCPDirection(MOTOR_C_TIMER, DL_TIMER_CC0_OUTPUT);
    DL_Timer_startCounter(MOTOR_C_TIMER);

    /* ---- Motor D PWM: TIMG8 → PA23 ---- */
    DL_Timer_reset(MOTOR_D_TIMER);
    DL_Timer_enablePower(MOTOR_D_TIMER);
    delay_cycles(POWER_STARTUP_DELAY);

    DL_GPIO_initPeripheralOutputFunction(MOTOR_D_IOMUX,
        IOMUX_PINCM53_PF_TIMG8_CCP0);
    DL_GPIO_enableOutput(MOTOR_D_PORT, MOTOR_D_PIN);

    DL_Timer_setClockConfig(MOTOR_D_TIMER, &clk_cfg);
    DL_TimerG_initPWMMode(MOTOR_D_TIMER, &pwm_cfg);

    DL_Timer_setCaptureCompareOutCtl(MOTOR_D_TIMER,
        DL_TIMER_CC_OCTL_INIT_VAL_LOW,
        DL_TIMER_CC_OCTL_INV_OUT_DISABLED,
        DL_TIMER_CC_OCTL_SRC_FUNCVAL, MOTOR_D_CCP_IDX);
    DL_Timer_setCaptCompUpdateMethod(MOTOR_D_TIMER,
        DL_TIMER_CC_UPDATE_METHOD_IMMEDIATE, MOTOR_D_CCP_IDX);
    DL_Timer_setCaptureCompareValue(MOTOR_D_TIMER, 0, MOTOR_D_CCP_IDX);

    DL_Timer_enableClock(MOTOR_D_TIMER);
    DL_Timer_setCCPDirection(MOTOR_D_TIMER, DL_TIMER_CC0_OUTPUT);
    DL_Timer_startCounter(MOTOR_D_TIMER);
}

/*
 * bsp_motor_set_pwm_cd — 设置 Motor C/D 占空比 + 方向
 *
 *   pwmC/pwmD: ±7999, 与 Motor A/B 一致
 *   pwm>0 → AIN2/BIN2=HIGH, AIN1/BIN1=LOW (正转)
 *   pwm<0 → AIN1/BIN1=HIGH, AIN2/BIN2=LOW (反转)
 */
void bsp_motor_set_pwm_cd(int32_t pwmC, int32_t pwmD)
{
    /* Motor C direction (C_AIN1=PA9, C_AIN2=PA19) */
    if (pwmC > 0) {
        DL_GPIO_setPins(MOTOR_C_AIN2_PORT, MOTOR_C_AIN2_PIN);
        DL_GPIO_clearPins(MOTOR_C_AIN1_PORT, MOTOR_C_AIN1_PIN);
    } else {
        DL_GPIO_setPins(MOTOR_C_AIN1_PORT, MOTOR_C_AIN1_PIN);
        DL_GPIO_clearPins(MOTOR_C_AIN2_PORT, MOTOR_C_AIN2_PIN);
    }

    /* Motor D direction (D_BIN1=PA20, D_BIN2=PB1) */
    if (pwmD > 0) {
        DL_GPIO_setPins(MOTOR_D_BIN2_PORT, MOTOR_D_BIN2_PIN);
        DL_GPIO_clearPins(MOTOR_D_BIN1_PORT, MOTOR_D_BIN1_PIN);
    } else {
        DL_GPIO_setPins(MOTOR_D_BIN1_PORT, MOTOR_D_BIN1_PIN);
        DL_GPIO_clearPins(MOTOR_D_BIN2_PORT, MOTOR_D_BIN2_PIN);
    }

    DL_Timer_setCaptureCompareValue(MOTOR_C_TIMER,
        (uint32_t)ABS(pwmC), MOTOR_C_CCP_IDX);
    DL_Timer_setCaptureCompareValue(MOTOR_D_TIMER,
        (uint32_t)ABS(pwmD), MOTOR_D_CCP_IDX);
}

int32_t bsp_motor_velocity_A(int32_t target, int32_t current)
{
    int32_t bias = target - current;

    ControlVelocityA += Velcity_Ki * (float)(bias - Last_biasA) + Velcity_Kp * (float)bias;
    Last_biasA = bias;

    return bsp_motor_limit_pwm((int32_t)ControlVelocityA, PWM_MIN, PWM_MAX);
}

int32_t bsp_motor_velocity_B(int32_t target, int32_t current)
{
    int32_t bias = target - current;

    ControlVelocityB += Velcity_Ki * (float)(bias - Last_biasB) + Velcity_Kp * (float)bias;
    Last_biasB = bias;

    return bsp_motor_limit_pwm((int32_t)ControlVelocityB, PWM_MIN, PWM_MAX);
}
