/*
 * 四串口驱动 — 环形缓冲 + ISR 收发
 *
 * ┌───────────────────────────────────────────────────────────────────┐
 * │                    UART  数据流架构                                │
 * │                                                                   │
 * │  UART0 (PA10-TX / PA11-RX):  调试通道                            │
 * │    TX:  debug_print() → uart_putc() → UART0 TX → 上位机串口助手    │
 * │    RX:  上位机 → UART0 RX → UART0_IRQHandler → rx_buf[256]        │
 * │         → uart_rxbuf_pop() → 命令解析Task (暂未实现)               │
 * │                                                                   │
 * │  UART1 (PB4-TX / PB5-RX):  IMU 姿态传感器                         │
 * │    RX:  WitMotion IMU → UART1 RX → UART1_IRQHandler               │
 * │         → imu_rx_buf[256] → uart_imu_rxbuf_pop()                  │
 * │         → imu_yabo_process() → chassis_move.imu                   │
 * │    TX:  未使用 (IMU只发不收, 无需MCU向其发送配置指令)               │
 * │                                                                   │
 * │  UART2 (PA21-TX / PA22-RX):  摄像头通信 (预留)                    │
 * │    RX:  摄像头模块 → UART2 RX → UART2_IRQHandler                  │
 * │         → cam_rx_buf[256] → bsp_uart_cam_rxbuf_pop()              │
 * │         → 未来 bsp_cam 模块解析                                    │
 * │    TX:  未来实现 → DL_UART_Main_transmitData(UART_2_INST)          │
 * │                                                                   │
 * │  UART3 (PB12-TX / PB13-RX):  蓝牙透传 (预留)                      │
 * │    RX:  蓝牙模块(如HC-05/JDY-31) → UART3 RX → UART3_IRQHandler    │
 * │         → bt_rx_buf[256] → bsp_uart_bt_rxbuf_pop()                │
 * │         → 未来蓝牙协议栈/App通信协议                                │
 * │    TX:  未来实现 → DL_UART_Main_transmitData(UART_3_INST)          │
 * │         典型场景: 手机App ←蓝牙→ HC-05 ←UART3→ MSPM0              │
 * │                                                                   │
 * └───────────────────────────────────────────────────────────────────┘
 *
 * 环形缓冲规则 (ISR生产者 / Task消费者):
 *   head == tail        → 缓冲区空 (无数据可读)
 *   (head+1)%SIZE==tail → 缓冲区满 (新字节将被丢弃)
 *
 * SysConfig 回环模式修复:
 *   SysConfig 默认生成 loopback=ON 的 UART 配置, 导致 RX 只能接收
 *   自身 TX 发出的数据. 每个 bsp_uart_*_init() 通过以下流程关闭回环:
 *     1. DL_UART_Main_changeConfig()  → 取回句柄控制权
 *     2. DL_UART_Main_disableLoopbackMode() → 关闭回环
 *     3. re-enable FIFOs + set thresholds → 重配硬件FIFO
 *     4. DL_UART_Main_enable() → 使能外设
 */

#include <stdio.h>
#include <stdarg.h>
#include "ti_msp_dl_config.h"
#include "bsp_uart.h"

/* ================================================================
 *  UART0: 调试串口
 *  PA10-TX / PA11-RX, 115200-8-N-1
 *  TX走uart_putc(), RX通过环形缓冲供Task读取
 * ================================================================ */

static void uart_putc(char c)
{
    while (DL_UART_isBusy(UART_0_INST));
    DL_UART_Main_transmitData(UART_0_INST, (uint8_t)c);
}

/* ---- UART0 环形缓冲 (ISR push, Task pop) ---- */
#define RX_BUF_SIZE 256
volatile uint8_t  rx_buf[RX_BUF_SIZE];
static volatile uint16_t rx_head = 0;
static volatile uint16_t rx_tail = 0;

bool uart_rxbuf_pop(uint8_t *byte)
{
    if (rx_head == rx_tail) return false;
    *byte = rx_buf[rx_tail];
    rx_tail = (rx_tail + 1) % RX_BUF_SIZE;
    return true;
}

static void uart_rxbuf_push(uint8_t byte)
{
    uint16_t next = (rx_head + 1) % RX_BUF_SIZE;
    if (next == rx_tail) return;        /* 缓冲区满, 丢弃 */
    rx_buf[rx_head] = byte;
    rx_head = next;
}

void UART0_IRQHandler(void)
{
    uint32_t status = DL_UART_Main_getEnabledInterruptStatus(UART_0_INST,
        DL_UART_MAIN_INTERRUPT_RX);

    if (status & DL_UART_MAIN_INTERRUPT_RX) {
        while (!DL_UART_Main_isRXFIFOEmpty(UART_0_INST)) {
            uart_rxbuf_push((uint8_t)DL_UART_Main_receiveData(UART_0_INST));
        }
    }
}

/* ---- printf 重定向 (fputc 走 UART0) ---- */
int fputc(int ch, FILE *f)
{
    uart_putc((char)ch);
    return ch;
}

void bsp_uart_init(void)
{
    /*
     * SysConfig 的 SYSCFG_DL_UART_0_init() 已经做了时钟/引脚/波特率配置,
     * 但开启了 loopback mode. 这里接管控制权, 关闭回环, 重配FIFO,
     * 然后使能RX中断.
     *
     * 调用链: main.c → main_blinky() → prvSetupHardware() → bsp_uart_init()
     */
    DL_UART_Main_changeConfig(UART_0_INST);
    DL_UART_Main_disableLoopbackMode(UART_0_INST);
    DL_UART_Main_enableFIFOs(UART_0_INST);
    DL_UART_Main_setRXFIFOThreshold(UART_0_INST, DL_UART_RX_FIFO_LEVEL_ONE_ENTRY);
    DL_UART_Main_setTXFIFOThreshold(UART_0_INST, DL_UART_TX_FIFO_LEVEL_1_2_EMPTY);
    DL_UART_Main_enable(UART_0_INST);

    DL_UART_Main_enableInterrupt(UART_0_INST, DL_UART_MAIN_INTERRUPT_RX);
    NVIC_EnableIRQ(UART_0_INST_INT_IRQN);
}

/* ================================================================
 *  UART1: IMU 串口
 *  PB4-TX / PB5-RX, 115200-8-N-1
 *  WitMotion IMU 单向发送姿态数据, 无需MCU向其TX
 * ================================================================ */

#define IMU_RX_BUF_SIZE 256
volatile uint8_t  imu_rx_buf[IMU_RX_BUF_SIZE];
static volatile uint16_t imu_rx_head = 0;
static volatile uint16_t imu_rx_tail = 0;

bool uart_imu_rxbuf_pop(uint8_t *byte)
{
    if (imu_rx_head == imu_rx_tail) return false;
    *byte = imu_rx_buf[imu_rx_tail];
    imu_rx_tail = (imu_rx_tail + 1) % IMU_RX_BUF_SIZE;
    return true;
}

static void uart_imu_rxbuf_push(uint8_t byte)
{
    uint16_t next = (imu_rx_head + 1) % IMU_RX_BUF_SIZE;
    if (next == imu_rx_tail) return;
    imu_rx_buf[imu_rx_head] = byte;
    imu_rx_head = next;
}

void UART1_IRQHandler(void)
{
    uint32_t status = DL_UART_Main_getEnabledInterruptStatus(UART_1_INST,
        DL_UART_MAIN_INTERRUPT_RX);

    if (status & DL_UART_MAIN_INTERRUPT_RX) {
        while (!DL_UART_Main_isRXFIFOEmpty(UART_1_INST)) {
            uart_imu_rxbuf_push((uint8_t)DL_UART_Main_receiveData(UART_1_INST));
        }
    }
}

void bsp_uart_imu_init(void)
{
    /*
     * IMU 串口必须关闭回环, 否则 RX 只能收到自身 TX (未连接) 的数据.
     * 调用链: main.c → prvSetupHardware() → bsp_uart_imu_init()
     * 数据流: IMU硬件 → 物理RX线 → UART1 RX FIFO → ISR → imu_rx_buf
     *         → 100Hz Task调用 uart_imu_rxbuf_pop → imu_yabo_process
     */
    DL_UART_Main_changeConfig(UART_1_INST);
    DL_UART_Main_disableLoopbackMode(UART_1_INST);
    DL_UART_Main_enableFIFOs(UART_1_INST);
    DL_UART_Main_setRXFIFOThreshold(UART_1_INST, DL_UART_RX_FIFO_LEVEL_ONE_ENTRY);
    DL_UART_Main_setTXFIFOThreshold(UART_1_INST, DL_UART_TX_FIFO_LEVEL_1_2_EMPTY);
    DL_UART_Main_enable(UART_1_INST);

    DL_UART_Main_enableInterrupt(UART_1_INST, DL_UART_MAIN_INTERRUPT_RX);
    NVIC_EnableIRQ(UART_1_INST_INT_IRQN);
}

/* ================================================================
 *  UART2: 摄像头串口 (预留)
 *  PA21-TX / PA22-RX, 115200-8-N-1
 *  当前仅配置硬件+环形缓冲, 上层解析暂未实现
 * ================================================================ */

#define CAM_RX_BUF_SIZE 256
volatile uint8_t  cam_rx_buf[CAM_RX_BUF_SIZE];
static volatile uint16_t cam_rx_head = 0;
static volatile uint16_t cam_rx_tail = 0;

bool bsp_uart_cam_rxbuf_pop(uint8_t *byte)
{
    if (cam_rx_head == cam_rx_tail) return false;
    *byte = cam_rx_buf[cam_rx_tail];
    cam_rx_tail = (cam_rx_tail + 1) % CAM_RX_BUF_SIZE;
    return true;
}

static void uart_cam_rxbuf_push(uint8_t byte)
{
    uint16_t next = (cam_rx_head + 1) % CAM_RX_BUF_SIZE;
    if (next == cam_rx_tail) return;
    cam_rx_buf[cam_rx_head] = byte;
    cam_rx_head = next;
}

void UART2_IRQHandler(void)
{
    uint32_t status = DL_UART_Main_getEnabledInterruptStatus(UART_2_INST,
        DL_UART_MAIN_INTERRUPT_RX);

    if (status & DL_UART_MAIN_INTERRUPT_RX) {
        while (!DL_UART_Main_isRXFIFOEmpty(UART_2_INST)) {
            uart_cam_rxbuf_push((uint8_t)DL_UART_Main_receiveData(UART_2_INST));
        }
    }
}

void bsp_uart_cam_init(void)
{
    /*
     * 摄像头串口 — 当前仅使能硬件接收通道.
     * 调用链: main.c → prvSetupHardware() → bsp_uart_cam_init()
     * 数据流: 摄像头 → UART2_RX → ISR → cam_rx_buf
     *         → (未来) bsp_cam模块调用 bsp_uart_cam_rxbuf_pop
     * TX功能待摄像头协议确定后实现.
     */
    DL_UART_Main_changeConfig(UART_2_INST);
    DL_UART_Main_disableLoopbackMode(UART_2_INST);
    DL_UART_Main_enableFIFOs(UART_2_INST);
    DL_UART_Main_setRXFIFOThreshold(UART_2_INST,
        DL_UART_RX_FIFO_LEVEL_ONE_ENTRY);
    DL_UART_Main_setTXFIFOThreshold(UART_2_INST,
        DL_UART_TX_FIFO_LEVEL_1_2_EMPTY);
    DL_UART_Main_enable(UART_2_INST);

    DL_UART_Main_enableInterrupt(UART_2_INST, DL_UART_MAIN_INTERRUPT_RX);
    NVIC_EnableIRQ(UART_2_INST_INT_IRQN);
}

/* ================================================================
 *  UART3: 蓝牙串口 (预留)
 *  PB12-TX / PB13-RX, 115200-8-N-1
 *  蓝牙透传模块通过 UART 与 MCU 进行双向数据交换.
 *  典型应用场景:
 *    - 手机 App ←蓝牙RF→ 蓝牙模块(HC-05/JDY-31) ←UART3→ MSPM0G3507
 *    - MCU 通过 UART3_TX 向手机发送传感器数据
 *    - 手机通过 UART3_RX 向 MCU 发送控制指令
 *  当前仅配置硬件+环形缓冲, 上层蓝牙协议栈暂未实现.
 *  注意: 蓝牙模块通常需要 AT 命令配置 (波特率/名称/配对码),
 *        这些配置应在系统初始化时通过 UART3_TX 发送.
 * ================================================================ */

#define BT_RX_BUF_SIZE 256
volatile uint8_t  bt_rx_buf[BT_RX_BUF_SIZE];
static volatile uint16_t bt_rx_head = 0;
static volatile uint16_t bt_rx_tail = 0;

/*
 * bsp_uart_bt_rxbuf_pop — 从蓝牙环形缓冲取出一个字节 (非阻塞)
 *
 *   调用方: 蓝牙协议栈 Task (未来实现)
 *   数据来源: 手机App → 蓝牙模块 → UART3_RX → 中断 → bt_rx_buf
 *   典型数据: JSON指令 / 二进制协议帧 / AT命令响应
 *   返回值:  true=取到数据, false=缓冲区空
 *
 *   使用示例 (伪代码):
 *     uint8_t ch;
 *     while (bsp_uart_bt_rxbuf_pop(&ch)) {
 *         bt_protocol_parse(ch);  // 逐字节送入蓝牙协议解析器
 *     }
 */
bool bsp_uart_bt_rxbuf_pop(uint8_t *byte)
{
    if (bt_rx_head == bt_rx_tail) return false;
    *byte = bt_rx_buf[bt_rx_tail];
    bt_rx_tail = (bt_rx_tail + 1) % BT_RX_BUF_SIZE;
    return true;
}

/*
 * uart_bt_rxbuf_push — ISR内部使用, 将接收字节写入环形缓冲
 *
 *   调用环境: UART3_IRQHandler (中断上下文)
 *   缓冲区满时的处理: 静默丢弃 (不阻塞, 不死锁)
 *     256字节 @115200bps ≈ 可缓冲约22ms的连续数据,
 *     足够容纳典型蓝牙透传帧 (通常<100字节)
 */
static void uart_bt_rxbuf_push(uint8_t byte)
{
    uint16_t next = (bt_rx_head + 1) % BT_RX_BUF_SIZE;
    if (next == bt_rx_tail) return;     /* 缓冲区满, 丢弃新字节 */
    bt_rx_buf[bt_rx_head] = byte;
    bt_rx_head = next;
}

/*
 * UART3_IRQHandler — 蓝牙串口接收中断服务程序
 *
 *   触发条件: 蓝牙模块通过 UART3_RX 发送数据, RX FIFO 达到阈值 (1字节)
 *   执行流程:
 *     1. 读取 UART3 已使能中断状态寄存器
 *     2. 若 RX 中断挂起, 从 RX FIFO 逐字节读取直到 FIFO 空
 *     3. 每字节通过 uart_bt_rxbuf_push 写入环形缓冲 bt_rx_buf
 *   中断优先级: 由 NVIC 默认配置 (通常为最低优先级)
 *   向量表位置: startup_mspm0g350x_gcc.c 的 UART3_IRQHandler 槽位
 */
void UART3_IRQHandler(void)
{
    uint32_t status = DL_UART_Main_getEnabledInterruptStatus(UART_3_INST,
        DL_UART_MAIN_INTERRUPT_RX);

    if (status & DL_UART_MAIN_INTERRUPT_RX) {
        while (!DL_UART_Main_isRXFIFOEmpty(UART_3_INST)) {
            uart_bt_rxbuf_push((uint8_t)DL_UART_Main_receiveData(UART_3_INST));
        }
    }
}

/*
 * bsp_uart_bt_init — UART3 蓝牙串口初始化
 *
 *   调用链: main.c → prvSetupHardware() → bsp_uart_bt_init()
 *           在 FreeRTOS 调度器启动前执行, 晚于 SYSCFG_DL_UART_3_init()
 *
 *   硬件配置流程:
 *     1. changeConfig  — 接管 UART3 的 DL_Main 句柄 (SysConfig 已配好时钟/引脚)
 *     2. disableLoopbackMode — 关闭回环 (SysConfig默认开启, 必须关闭才能接收外部数据)
 *     3. enableFIFOs + setRXFIFOThreshold — RX FIFO深度1 (收到1字节即触发中断)
 *     4. setTXFIFOThreshold — TX FIFO 1/2满标志 (发送时用)
 *     5. enable + enableInterrupt(RX) — 使能外设和RX中断
 *     6. NVIC_EnableIRQ — 在 Cortex-M0+ NVIC 中使能 UART3 中断线
 *
 *   引脚配置 (由 SYSCFG_DL_init 提前完成):
 *     TX: PB12, IOMUX_PINCM29, 外设功能 UART3_TX (PF=2)
 *     RX: PB13, IOMUX_PINCM30, 外设功能 UART3_RX (PF=2)
 *
 *   物理连接:
 *     蓝牙模块 TX  ──→ MSPM0 PB13 (UART3_RX)
 *     蓝牙模块 RX  ──→ MSPM0 PB12 (UART3_TX)
 *     蓝牙模块 VCC ──→ 3.3V
 *     蓝牙模块 GND ──→ GND
 *     (HC-05 的 KEY/EN 引脚如需进入 AT 模式, 需另接 GPIO 控制)
 *
 *   后续工作 (TODO):
 *     - 实现蓝牙协议栈 Task 从 bt_rx_buf 读取并解析数据
 *     - 实现 bsp_uart_bt_send() 封装 DL_UART_Main_transmitDataBlocking
 *     - AT 命令配置 (如果使用 HC-05 等经典蓝牙模块)
 */
void bsp_uart_bt_init(void)
{
    DL_UART_Main_changeConfig(UART_3_INST);
    DL_UART_Main_disableLoopbackMode(UART_3_INST);
    DL_UART_Main_enableFIFOs(UART_3_INST);
    DL_UART_Main_setRXFIFOThreshold(UART_3_INST,
        DL_UART_RX_FIFO_LEVEL_ONE_ENTRY);
    DL_UART_Main_setTXFIFOThreshold(UART_3_INST,
        DL_UART_TX_FIFO_LEVEL_1_2_EMPTY);
    DL_UART_Main_enable(UART_3_INST);

    DL_UART_Main_enableInterrupt(UART_3_INST, DL_UART_MAIN_INTERRUPT_RX);
    NVIC_EnableIRQ(UART_3_INST_INT_IRQN);
}

/* ================================================================
 *  通用发送接口 (走 UART0 调试通道)
 * ================================================================ */

void bsp_uart_send_byte(uint8_t ch)
{
    uart_putc((char)ch);
}

void bsp_uart_send_str(const char *str)
{
    while (*str) uart_putc(*str++);
}

/* ================================================================
 *  轻量级 debug_print: 完全不分配堆内存, 纯栈操作
 *  支持: %d %ld %u %lu %c %s %x %X  不支持: %f
 *  输出: UART0 TX (PA10)
 *
 *  实现原理:
 *    逐字符扫描格式串, 遇到 % 则解析后续格式说明符,
 *    调用 va_arg 从变参栈取参数值, 转为字符串后逐字符发送.
 *    所有临时缓冲区(digit_buf, hex_buf)都分配在栈上.
 * ================================================================ */
void debug_print(const char *fmt, ...)
{
    va_list args;
    va_start(args, fmt);

    while (*fmt) {
        if (*fmt == '%' && *(fmt + 1) != '\0') {
            fmt++;
            int is_long = 0;

            while (*fmt == '0' || *fmt == '-' || *fmt == '+') fmt++;
            while (*fmt >= '0' && *fmt <= '9') fmt++;
            if (*fmt == 'l') { is_long = 1; fmt++; }

            switch (*fmt) {
            case 'd': {
                if (is_long) {
                    long v = va_arg(args, long);
                    if (v < 0) { uart_putc('-'); v = -v; }
                    if (v == 0) { uart_putc('0'); break; }
                    char buf[12]; int i = 0;
                    while (v) { buf[i++] = '0' + (v % 10); v /= 10; }
                    while (i) uart_putc(buf[--i]);
                } else {
                    int v = va_arg(args, int);
                    if (v < 0) { uart_putc('-'); v = -v; }
                    if (v == 0) { uart_putc('0'); break; }
                    char buf[12]; int i = 0;
                    while (v) { buf[i++] = '0' + (v % 10); v /= 10; }
                    while (i) uart_putc(buf[--i]);
                }
                break;
            }
            case 'u': {
                if (is_long) {
                    unsigned long v = va_arg(args, unsigned long);
                    if (v == 0) { uart_putc('0'); break; }
                    char buf[12]; int i = 0;
                    while (v) { buf[i++] = '0' + (v % 10); v /= 10; }
                    while (i) uart_putc(buf[--i]);
                } else {
                    unsigned int v = va_arg(args, unsigned int);
                    if (v == 0) { uart_putc('0'); break; }
                    char buf[12]; int i = 0;
                    while (v) { buf[i++] = '0' + (v % 10); v /= 10; }
                    while (i) uart_putc(buf[--i]);
                }
                break;
            }
            case 'x':
            case 'X': {
                unsigned int v = va_arg(args, unsigned int);
                char hex[9]; int i = 0;
                char base = (*fmt == 'X') ? 'A' : 'a';
                if (v == 0) hex[i++] = '0';
                while (v) {
                    int d = v & 0xF;
                    hex[i++] = (d < 10) ? ('0' + d) : (base + d - 10);
                    v >>= 4;
                }
                while (i) uart_putc(hex[--i]);
                break;
            }
            case 'c': {
                char c = (char)va_arg(args, int);
                uart_putc(c);
                break;
            }
            case 's': {
                char *s = va_arg(args, char*);
                if (s) while (*s) uart_putc(*s++);
                else bsp_uart_send_str("(null)");
                break;
            }
            default:
                uart_putc('%');
                uart_putc(*fmt);
                break;
            }
            fmt++;
        } else {
            uart_putc(*fmt++);
        }
    }
    va_end(args);
}
