/*
 * 蓝牙透传通信驱动
 *
 * 数据流 (未来实现):
 *   TX: 应用层 → bsp_bluetooth_send() → DL_UART_Main_transmitData(UART_3_INST)
 *         → UART3_TX(PB12) → 蓝牙模块 → 手机App
 *   RX: 手机App → 蓝牙模块 → UART3_RX(PB13) → UART3_IRQHandler
 *         → bt_rx_buf[256] → bsp_bluetooth_read() → bsp_uart_bt_rxbuf_pop() → 应用层
 *
 * 典型使用场景:
 *   1. 手机远程遥控: App 发送 "FW:100" → 解析为前进速度100
 *   2. 传感器数据上报: MCU 定时发送 "{yaw:45.2,pitch:-3.1,roll:1.8}" → 手机显示
 *   3. 参数配置: App 发送 "PID:200,3,10" → MCU 在线更新PID参数
 *
 * 当前状态: UART3 硬件已在 bsp_uart_bt_init() 中使能,
 *          bt_rx_buf 环形缓冲已在 bsp_uart.c 中定义,
 *          本文件仅提供应用层接口桩函数, 等待蓝牙协议栈实现.
 */

#include "bsp_bluetooth.h"
#include "bsp_uart.h"
#include "ti_msp_dl_config.h"

void bsp_bluetooth_init(void)
{
    /*
     * UART3 硬件初始化已在 bsp_uart_bt_init() 中完成 (bsp_uart.c)
     * 此处保留以支持将来的蓝牙模块专属配置:
     *   - 发送 AT 命令序列 (设置名称/波特率/配对码/模式)
     *   - 等待蓝牙模块就绪 (HC-05 上电后约需200ms)
     *   - 设置蓝牙模块工作模式 (透传/AT命令)
     *
     * HC-05 AT 命令示例 (通过 UART3_TX 发送, 末尾加 \r\n):
     *   AT\r\n              测试连接 (模块应回复 OK)
     *   AT+NAME=MSPM0_BT\r\n 设置蓝牙名称
     *   AT+UART=115200,0,0\r\n 设置串口参数
     *   AT+ROLE=0\r\n        设置从机模式
     */
}

void bsp_bluetooth_send(const uint8_t *data, uint16_t len)
{
    (void)data;
    (void)len;
    /*
     * TODO: 逐字节发送透传数据到蓝牙模块
     *   for (uint16_t i = 0; i < len; i++) {
     *       while (DL_UART_isBusy(UART_3_INST));
     *       DL_UART_Main_transmitData(UART_3_INST, data[i]);
     *   }
     * 或者使用 DL_UART_Main_transmitDataBlocking() 批量发送
     */
}

bool bsp_bluetooth_read(uint8_t *data, uint16_t *len)
{
    (void)data;
    (void)len;
    /*
     * TODO: 从 bt_rx_buf 环形缓冲读取透传数据
     *   uint16_t cnt = 0;
     *   while (cnt < *len && bsp_uart_bt_rxbuf_pop(&data[cnt])) {
     *       cnt++;
     *   }
     *   *len = cnt;
     *   return cnt > 0;
     */
    return false;
}
