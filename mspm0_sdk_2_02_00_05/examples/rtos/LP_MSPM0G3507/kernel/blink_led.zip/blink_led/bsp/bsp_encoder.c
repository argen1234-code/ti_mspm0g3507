/*
 * 四路正交编码器驱动 — GPIO 中断 + 二倍频计数
 *
 * 数据流向:
 *   电机旋转 → 编码器 A/B 相脉冲
 *   GPIO 边沿中断 (GROUP1_IRQHandler)
 *     ├─ E1A/E1B (PA25/PA26) ──→ g_encoderA_cnt (左轮, 100Hz task 读取)
 *     ├─ E2A/E2B (PB20/PB24) ──→ g_encoderB_cnt (右轮, 100Hz task 读取)
 *     ├─ E3A/E3B (PB6/PB7)   ──→ g_encoderC_cnt (预留, 硬件已使能)
 *     ├─ E4A/E4B (PA27/PA31) ──→ g_encoderD_cnt (预留, 硬件已使能)
 *     └─ KEY1/KEY2 (PA18/PA24) ──→ bsp_key_gpio_isr() → TIMG6 去抖
 *
 * 二倍频原理 (每相上升沿计数一次):
 *   编码器 A 相上升沿: B 相高 → 正转+1, B 相低 → 反转-1
 *   编码器 B 相上升沿: A 相高 → 反转-1, A 相低 → 正转+1
 *   实际效果: 每条线产生 2 个脉冲 (二倍频), 也可同时使能上升+下降沿得四倍频
 *
 *   13线 × 2 × 30:1 = 780 脉冲/输出轴转 (二倍频时)
 *
 * 中断架构:
 *   GPIOA_INT_IRQn → GROUP1_IIDX_GPIOA → GROUP1_IRQHandler
 *     → 检查 PA25/PA26/PA27/PA31 中断状态
 *   GPIOB_INT_IRQn → GROUP1_IIDX_GPIOB → GROUP1_IRQHandler
 *     → 检查 PB20/PB24/PB6/PB7 中断状态
 *
 *   所有 GPIO 中断共享 GROUP1_IRQHandler, ISR 内通过
 *   DL_GPIO_getEnabledInterruptStatus 区分具体引脚.
 */

#include "ti_msp_dl_config.h"
#include "bsp_encoder.h"
#include "bsp_key.h"

volatile int32_t g_encoderA_cnt = 0;
volatile int32_t g_encoderB_cnt = 0;
volatile int32_t g_encoderC_cnt = 0;
volatile int32_t g_encoderD_cnt = 0;

void bsp_encoder_init(void)
{
    /*
     * Encoder A/B 引脚已在 SYSCFG_DL_GPIO_init() 中配置,
     * 但 NVIC 中断使能可能漏掉, 在此补上.
     *
     * Encoder C/D 引脚未在 SysConfig 中配置, 此处直接调用
     * DL_GPIO API 完成: 数字输入 + 无上下拉 + 上升沿中断.
     */

    /* ---- Encoder C: PB6(E3A), PB7(E3B) 上升沿中断 ---- */
    DL_GPIO_initDigitalInputFeatures(ENCODERC_E3A_IOMUX,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_NONE,
        DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);
    DL_GPIO_setUpperPinsPolarity(ENCODERC_PORT,
        DL_GPIO_PIN_6_EDGE_RISE | DL_GPIO_PIN_7_EDGE_RISE);
    DL_GPIO_clearInterruptStatus(ENCODERC_PORT,
        ENCODERC_E3A_PIN | ENCODERC_E3B_PIN);
    DL_GPIO_enableInterrupt(ENCODERC_PORT,
        ENCODERC_E3A_PIN | ENCODERC_E3B_PIN);

    /* ---- Encoder D: PA27(E4A), PA31(E4B) 上升沿中断 ---- */
    DL_GPIO_initDigitalInputFeatures(ENCODERD_E4A_IOMUX,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_NONE,
        DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);
    DL_GPIO_initDigitalInputFeatures(ENCODERD_E4B_IOMUX,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_NONE,
        DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);
    DL_GPIO_setUpperPinsPolarity(ENCODERD_PORT,
        DL_GPIO_PIN_27_EDGE_RISE | DL_GPIO_PIN_31_EDGE_RISE);
    DL_GPIO_clearInterruptStatus(ENCODERD_PORT,
        ENCODERD_E4A_PIN | ENCODERD_E4B_PIN);
    DL_GPIO_enableInterrupt(ENCODERD_PORT,
        ENCODERD_E4A_PIN | ENCODERD_E4B_PIN);

    /* NVIC 中断使能: GPIOA/GPIOB GROUP1 中断 */
    NVIC_EnableIRQ(GPIOA_INT_IRQn);
    NVIC_EnableIRQ(GPIOB_INT_IRQn);
}

/*
 * GROUP1_IRQHandler — GPIO 组合中断服务程序
 *
 *   处理所有 GPIOA + GPIOB 的编码器中断.
 *   Cortex-M0+ 无中断嵌套, ISR 执行期间同优先级中断排队.
 *
 *   每路编码器的处理:
 *     1. 读取该端口已使能的挂起中断状态
 *     2. 检查 A 相: 根据 B 相电平决定±1
 *     3. 检查 B 相: 根据 A 相电平决定±1
 *     4. 清除中断标志 (否则立即再次触发)
 *
 *   注: 编码器 C/D 仅计数, 当前无任务消费 g_encoderC/D_cnt.
 */
void GROUP1_IRQHandler(void)
{
    uint32_t status;

    /* ---- Encoder A: E1A=PA25, E1B=PA26 (GPIOA) ---- */
    status = DL_GPIO_getEnabledInterruptStatus(ENCODERA_PORT,
        ENCODERA_E1A_PIN | ENCODERA_E1B_PIN);
    if (status & ENCODERA_E1A_PIN) {
        if (DL_GPIO_readPins(ENCODERA_PORT, ENCODERA_E1B_PIN))
            g_encoderA_cnt--;
        else
            g_encoderA_cnt++;
    }
    if (status & ENCODERA_E1B_PIN) {
        if (DL_GPIO_readPins(ENCODERA_PORT, ENCODERA_E1A_PIN))
            g_encoderA_cnt++;
        else
            g_encoderA_cnt--;
    }
    DL_GPIO_clearInterruptStatus(ENCODERA_PORT,
        ENCODERA_E1A_PIN | ENCODERA_E1B_PIN);

    /* ---- Encoder B: E2A=PB20, E2B=PB24 (GPIOB) ---- */
    status = DL_GPIO_getEnabledInterruptStatus(ENCODERB_PORT,
        ENCODERB_E2A_PIN | ENCODERB_E2B_PIN);
    if (status & ENCODERB_E2A_PIN) {
        if (DL_GPIO_readPins(ENCODERB_PORT, ENCODERB_E2B_PIN))
            g_encoderB_cnt--;
        else
            g_encoderB_cnt++;
    }
    if (status & ENCODERB_E2B_PIN) {
        if (DL_GPIO_readPins(ENCODERB_PORT, ENCODERB_E2A_PIN))
            g_encoderB_cnt++;
        else
            g_encoderB_cnt--;
    }
    DL_GPIO_clearInterruptStatus(ENCODERB_PORT,
        ENCODERB_E2A_PIN | ENCODERB_E2B_PIN);

    /* ---- Encoder C: E3A=PB6, E3B=PB7 (GPIOB, 预留) ---- */
    status = DL_GPIO_getEnabledInterruptStatus(ENCODERC_PORT,
        ENCODERC_E3A_PIN | ENCODERC_E3B_PIN);
    if (status & ENCODERC_E3A_PIN) {
        if (DL_GPIO_readPins(ENCODERC_PORT, ENCODERC_E3B_PIN))
            g_encoderC_cnt--;
        else
            g_encoderC_cnt++;
    }
    if (status & ENCODERC_E3B_PIN) {
        if (DL_GPIO_readPins(ENCODERC_PORT, ENCODERC_E3A_PIN))
            g_encoderC_cnt++;
        else
            g_encoderC_cnt--;
    }
    DL_GPIO_clearInterruptStatus(ENCODERC_PORT,
        ENCODERC_E3A_PIN | ENCODERC_E3B_PIN);

    /* ---- Encoder D: E4A=PA27, E4B=PA31 (GPIOA, 预留) ---- */
    status = DL_GPIO_getEnabledInterruptStatus(ENCODERD_PORT,
        ENCODERD_E4A_PIN | ENCODERD_E4B_PIN);
    if (status & ENCODERD_E4A_PIN) {
        if (DL_GPIO_readPins(ENCODERD_PORT, ENCODERD_E4B_PIN))
            g_encoderD_cnt--;
        else
            g_encoderD_cnt++;
    }
    if (status & ENCODERD_E4B_PIN) {
        if (DL_GPIO_readPins(ENCODERD_PORT, ENCODERD_E4A_PIN))
            g_encoderD_cnt++;
        else
            g_encoderD_cnt--;
    }
    DL_GPIO_clearInterruptStatus(ENCODERD_PORT,
        ENCODERD_E4A_PIN | ENCODERD_E4B_PIN);

    /* ---- 按键 KEY1(PA18) / KEY2(PA24) 中断 (GPIOA) ---- */
    {
        uint32_t key_status = DL_GPIO_getEnabledInterruptStatus(KEY1_PORT,
            KEY1_PIN | KEY2_PIN);
        if (key_status) {
            bsp_key_gpio_isr(key_status);
            DL_GPIO_clearInterruptStatus(KEY1_PORT, key_status);
        }
    }
}

float bsp_encoder_calc_rpm(int32_t encoder_count, uint32_t sample_time_ms)
{
    float pulses_per_rev = (float)(ENCODER_LINES * MULTIPLY_FACTOR);
    float rpm;

    rpm  = ((float)encoder_count * 60000.0f) / (pulses_per_rev * (float)sample_time_ms);
    rpm /= (float)GEAR_RATIO;

    return rpm;
}
