/*
 * 四路舵机 PWM 驱动 — TIMA0 边沿对齐, 4路独立占空比
 *
 * 数据流:
 *   chassis_task() 或其他控制Task
 *     → bsp_servo_set_angle(0, 90)     // 设置通道0角度
 *     → bsp_servo_set_pulse(0, 1500)   // 或直接设置脉宽
 *     → DL_Timer_setCaptureCompareValue(TIMA0, tick, CCPx_INDEX)
 *     → TIMA0 硬件比较匹配 → CCPx 引脚输出 PWM → 舵机
 *
 * 时序要求:
 *   - 模拟舵机需要 50Hz (20ms) 周期的 PWM 信号
 *   - 每周期一次脉冲, 脉宽 0.5~2.5ms 对应 0°~180°
 *   - 信号持续无效会导致舵机失能 (无力矩)
 *
 * 功耗注意:
 *   - 单个 MG996R 堵转电流 ~2.5A @6V
 *   - 4个舵机同时堵转 >10A, 不可从 LaunchPad 3.3V 取电
 *   - 舵机必须由外部电源 (5~6V, 10A+) 独立供电
 *   - 舵机 GND 必须与 MSPM0 GND 共地
 */

#include "bsp_servo.h"

/* ---- TIMA0 4路 CCP 索引 ---- */
#define CCP0_IDX  DL_TIMER_CC_0_INDEX
#define CCP1_IDX  DL_TIMER_CC_1_INDEX
#define CCP2_IDX  DL_TIMER_CC_2_INDEX
#define CCP3_IDX  DL_TIMER_CC_3_INDEX

/*
 * bsp_servo_init — 初始化 TIMA0 为 4路舵机 PWM
 *
 *   调用链: main.c → prvSetupHardware() → bsp_servo_init()
 *           在 bsp_uart_*_init 之后, FreeRTOS 调度器启动之前
 *   初始化步骤:
 *     1. 使能 TIMA0 电源 + 复位
 *     2. 配置 4 个 GPIO 为外设输出 (TIMA0 CCP 功能)
 *     3. 配置 TIMA0 时钟 (BUSCLK/1, prescale=63 → 1.25MHz)
 *     4. 初始化边沿对齐 PWM 模式, period=25000 (20ms)
 *     5. 配置 4 路 CCP 输出控制 (低有效→高, 无反转, 由功能值触发)
 *     6. 设置 4 路初始占空比为中心点 (1500us → 1875 tick)
 *     7. 使能 TIMA0 时钟, 设置 CCP 方向为输出, 启动定时器
 *
 *   TIMA0 时钟树:
 *     BUSCLK (80MHz) → DIV_1 → prescale(63+1=64) → 1.25MHz timer clock
 *     1 tick = 0.8us, 周期 = 25000 tick = 20ms = 50Hz
 */
void bsp_servo_init(void)
{
    /* ---- 1. 电源 + 复位 ---- */
    DL_TimerA_reset(SERVO_TIMER_INST);
    DL_TimerA_enablePower(SERVO_TIMER_INST);

    /*
     * 启动延时: 等待电源稳定. POWER_STARTUP_DELAY=16 个循环,
     * 由 SysConfig 统一定义, 这里借用同一个值.
     */
    delay_cycles(POWER_STARTUP_DELAY);

    /* ---- 2. GPIO 外设功能初始化 ---- */
    DL_GPIO_initPeripheralOutputFunction(SERVO_IOMUX_CH0, SERVO_IOMUX_FUNC_CH0);
    DL_GPIO_enableOutput(SERVO_PORT_CH0, SERVO_PIN_CH0);
    DL_GPIO_initPeripheralOutputFunction(SERVO_IOMUX_CH1, SERVO_IOMUX_FUNC_CH1);
    DL_GPIO_enableOutput(SERVO_PORT_CH1, SERVO_PIN_CH1);
    DL_GPIO_initPeripheralOutputFunction(SERVO_IOMUX_CH2, SERVO_IOMUX_FUNC_CH2);
    DL_GPIO_enableOutput(SERVO_PORT_CH2, SERVO_PIN_CH2);
    DL_GPIO_initPeripheralOutputFunction(SERVO_IOMUX_CH3, SERVO_IOMUX_FUNC_CH3);
    DL_GPIO_enableOutput(SERVO_PORT_CH3, SERVO_PIN_CH3);

    /* ---- 3. 定时器时钟配置 ---- */
    static const DL_TimerA_ClockConfig clk_cfg = {
        .clockSel    = DL_TIMER_CLOCK_BUSCLK,
        .divideRatio = DL_TIMER_CLOCK_DIVIDE_1,
        .prescale    = SERVO_PRESCALE,
    };
    DL_TimerA_setClockConfig(SERVO_TIMER_INST,
        (DL_TimerA_ClockConfig *)&clk_cfg);

    /* ---- 4. PWM 模式初始化 ---- */
    static const DL_TimerA_PWMConfig pwm_cfg = {
        .pwmMode            = DL_TIMER_PWM_MODE_EDGE_ALIGN_UP,
        .period             = SERVO_PERIOD_TICK,
        .isTimerWithFourCC  = true,              /* TIMA0 有 4 路 CCP */
        .startTimer         = DL_TIMER_START,
    };
    DL_TimerA_initPWMMode(SERVO_TIMER_INST,
        (DL_TimerA_PWMConfig *)&pwm_cfg);

    /*
     * ---- 5. 配置 4 路 CCP 输出控制 ----
     *
     * 参数说明:
     *   INIT_VAL_LOW:      计数器=0 时输出低电平
     *   INV_OUT_DISABLED:  不反转输出极性
     *   SRC_FUNCVAL:       比较匹配时由函数值(fn)控制输出翻转
     *                      (edge-align-up 模式: fn=0→匹配时拉低, fn=1→匹配时拉高,
     *                       我们设为拉低, 则占空比由 INIT_VAL_LOW→匹配翻转控制,
     *                       实际输出: 0→高, 匹配值→低)
     *
     *   简化理解: 设置 fn=0, INIT_VAL_LOW, 则:
     *     计数器从0计到CCP值 → 输出高
     *     计数器超过CCP值到period → 输出低
     *     所以 pulse_width_us = CCP_value * 0.8us
     */

    /* CH0 */
    DL_TimerA_setCaptureCompareOutCtl(SERVO_TIMER_INST,
        DL_TIMER_CC_OCTL_INIT_VAL_LOW,
        DL_TIMER_CC_OCTL_INV_OUT_DISABLED,
        DL_TIMER_CC_OCTL_SRC_FUNCVAL, CCP0_IDX);
    DL_TimerA_setCaptCompUpdateMethod(SERVO_TIMER_INST,
        DL_TIMER_CC_UPDATE_METHOD_IMMEDIATE, CCP0_IDX);

    /* CH1 */
    DL_TimerA_setCaptureCompareOutCtl(SERVO_TIMER_INST,
        DL_TIMER_CC_OCTL_INIT_VAL_LOW,
        DL_TIMER_CC_OCTL_INV_OUT_DISABLED,
        DL_TIMER_CC_OCTL_SRC_FUNCVAL, CCP1_IDX);
    DL_TimerA_setCaptCompUpdateMethod(SERVO_TIMER_INST,
        DL_TIMER_CC_UPDATE_METHOD_IMMEDIATE, CCP1_IDX);

    /* CH2 */
    DL_TimerA_setCaptureCompareOutCtl(SERVO_TIMER_INST,
        DL_TIMER_CC_OCTL_INIT_VAL_LOW,
        DL_TIMER_CC_OCTL_INV_OUT_DISABLED,
        DL_TIMER_CC_OCTL_SRC_FUNCVAL, CCP2_IDX);
    DL_TimerA_setCaptCompUpdateMethod(SERVO_TIMER_INST,
        DL_TIMER_CC_UPDATE_METHOD_IMMEDIATE, CCP2_IDX);

    /* CH3 */
    DL_TimerA_setCaptureCompareOutCtl(SERVO_TIMER_INST,
        DL_TIMER_CC_OCTL_INIT_VAL_LOW,
        DL_TIMER_CC_OCTL_INV_OUT_DISABLED,
        DL_TIMER_CC_OCTL_SRC_FUNCVAL, CCP3_IDX);
    DL_TimerA_setCaptCompUpdateMethod(SERVO_TIMER_INST,
        DL_TIMER_CC_UPDATE_METHOD_IMMEDIATE, CCP3_IDX);

    /* ---- 6. 初始占空比: 中心点 (1500us → 1875 tick) ---- */
    uint16_t init_tick = 625U;  /* 500us, 起始时输出最小脉宽(舵机不动作) */
    DL_TimerA_setCaptureCompareValue(SERVO_TIMER_INST, init_tick, CCP0_IDX);
    DL_TimerA_setCaptureCompareValue(SERVO_TIMER_INST, init_tick, CCP1_IDX);
    DL_TimerA_setCaptureCompareValue(SERVO_TIMER_INST, init_tick, CCP2_IDX);
    DL_TimerA_setCaptureCompareValue(SERVO_TIMER_INST, init_tick, CCP3_IDX);

    /* ---- 7. 使能定时器时钟 + CCP 输出方向 + 启动 ---- */
    DL_TimerA_enableClock(SERVO_TIMER_INST);
    DL_TimerA_setCCPDirection(SERVO_TIMER_INST,
        DL_TIMER_CC0_OUTPUT | DL_TIMER_CC1_OUTPUT |
        DL_TIMER_CC2_OUTPUT | DL_TIMER_CC3_OUTPUT);
}

/*
 * bsp_servo_set_pulse — 设置指定通道的脉宽
 *
 *   ch:       0~3, 对应 CH0(CH3)
 *   pulse_us: 脉宽值, 单位微秒.
 *             超出 [SERVO_MIN_PULSE_US, SERVO_MAX_PULSE_US] 将钳位,
 *             防止超出舵机物理行程范围.
 *
 *   转换: tick = pulse_us / SERVO_TICK_US (0.8us/tick)
 *   更新: 立即生效 (DL_TIMER_CC_UPDATE_METHOD_IMMEDIATE)
 *
 *   注意: 此函数在 task 上下文调用, 不在 ISR 中.
 *         TIMA0 无中断使能, 仅输出 PWM.
 */
void bsp_servo_set_pulse(uint8_t ch, uint16_t pulse_us)
{
    /* 钳位到允许范围 */
    if (pulse_us < SERVO_MIN_PULSE_US) pulse_us = SERVO_MIN_PULSE_US;
    if (pulse_us > SERVO_MAX_PULSE_US) pulse_us = SERVO_MAX_PULSE_US;

    uint16_t tick = (uint16_t)((float)pulse_us / SERVO_TICK_US);
    uint8_t idx;

    switch (ch) {
    case 0: idx = CCP0_IDX; break;
    case 1: idx = CCP1_IDX; break;
    case 2: idx = CCP2_IDX; break;
    case 3: idx = CCP3_IDX; break;
    default: return;
    }

    DL_TimerA_setCaptureCompareValue(SERVO_TIMER_INST, tick, idx);
}

/*
 * bsp_servo_set_angle — 设置指定通道的角度
 *
 *   ch:  0~3
 *   deg: 角度 0~180°, 线性映射:
 *          tick = MIN_TICK + (deg/180) * (MAX_TICK - MIN_TICK)
 *
 *   0°   → SERVO_MIN_PULSE_US (典型 500us)
 *   90°  → 1500us
 *   180° → SERVO_MAX_PULSE_US (典型 2500us)
 *
 *   角度超出 180° 将钳位.
 *   内部调用 bsp_servo_set_pulse, 复用其钳位逻辑.
 */
void bsp_servo_set_angle(uint8_t ch, uint8_t deg)
{
    if (deg > 180U) deg = 180U;

    /*
     * 脉宽 = MIN + (deg/180) * (MAX - MIN)
     * 使用 (MAX_TICK-MIN_TICK) 先转换为tick差值再乘以百分比,
     * 避免浮点运算 (Cortex-M0+ 无硬件浮点, 软浮点缓慢).
     *
     * 但此处保留简单 float 实现, 因为:
     *   1. 舵机角度更新频率很低 (通常 <50Hz)
     *   2. Cortex-M0+ 软浮点在此场景下性能足够
     *   3. 代码清晰易读, 舵机参数调整时方便验证
     * 如需极致性能, 可将 (MAX_TICK-MIN_TICK)/180 预计算为整型 Q 定点.
     */
    uint32_t range_tick = SERVO_MAX_PULSE_TICK - SERVO_MIN_PULSE_TICK;
    uint16_t tick = SERVO_MIN_PULSE_TICK +
                    (uint16_t)((uint32_t)deg * range_tick / 180U);
    uint16_t pulse_us = (uint16_t)((float)tick * SERVO_TICK_US);

    bsp_servo_set_pulse(ch, pulse_us);
}
