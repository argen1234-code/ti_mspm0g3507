/*
 * 两路按键驱动 — GPIO 下降沿中断 + TIMG6 硬件去抖
 *
 * 数据流:
 *   KEY1 (PA18), KEY2 (PA24)
 *     │ 下降沿触发 GPIOA_INT → GROUP1_IRQHandler
 *     │   └─ bsp_key_gpio_isr(status)
 *     │        ├─ 关闭对应按键中断 (防抖窗口)
 *     │        └─ 启动 TIMG6 单次 20ms
 *     │
 *     ▼ TIMG6_IRQHandler
 *        ├─ 读取按键电平 (20ms 后稳定值)
 *        ├─ 仍为低 → 有效按下, state=PRESSED, press_count++
 *        ├─ 已变高 → 抖动, 丢弃
 *        └─ 重新使能该按键中断
 *
 *   bsp_key_update() (100Hz 周期调用):
 *     轮询释放: state=PRESSED 时读 GPIO, 变高则→SHORT/LONG
 *     长按检测: hold_duration 累加, >= 1000ms → LONG
 *
 * 去抖时序:
 *   ──┐  ┌────── 按键电平 (有抖动)
 *     └──┘  └──┐
 *    ↓          ↓
 *   IRQ      TIMG6到期
 *   关中断    读电平=低
 *   启TIMG6   确认按下
 *
 * 引脚:
 *   KEY1: PA18 (SysConfig GPIO2 已配为数字输入), PINCM40
 *   KEY2: PA24 (bsp_key_init 配置), PINCM54
 *   均为: 上拉输入, 下降沿中断, 低电平=按下
 */

#include "ti_msp_dl_config.h"
#include "bsp_key.h"

/* ---- 全局按键实例 ---- */
key_dev_t g_key1 = {0};
key_dev_t g_key2 = {0};

/* 去抖中标志: bit0=KEY1, bit1=KEY2, ISR 写 / TIMG6 ISR 清除 */
static volatile uint8_t g_key_debounce_pending = 0;

/*
 * TIMG6 时钟:
 *   BUSCLK = 80MHz, prescale = 79 → timerClk = 1MHz
 *   20ms = 20000 ticks → period = 19999 (从 19999 减到 0)
 *   One-shot 模式: 启动后减到 0 触发 ZERO 中断, 自动停止
 */
#define TIMG6_PRESCALE      (79U)
#define TIMG6_TICK_HZ       (1000000UL)
#define TIMG6_PERIOD_TICKS  (20000U - 1U)  /* 20ms */

void bsp_key_init(void)
{
    /*
     * KEY1 (PA18): SysConfig GPIO2 已调用 DL_GPIO_initDigitalInputFeatures,
     *   但未配置中断. 此处直接补充: 下降沿极性 + 使能中断.
     */
    DL_GPIO_setUpperPinsPolarity(KEY1_PORT,
        DL_GPIO_PIN_18_EDGE_FALL);
    DL_GPIO_clearInterruptStatus(KEY1_PORT, KEY1_PIN);
    DL_GPIO_enableInterrupt(KEY1_PORT, KEY1_PIN);

    /*
     * KEY2 (PA24): 完整配置 GPIO 数字输入 + 上拉 + 下降沿中断.
     */
    DL_GPIO_initDigitalInputFeatures(KEY2_IOMUX,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);
    DL_GPIO_setUpperPinsPolarity(KEY2_PORT,
        DL_GPIO_PIN_24_EDGE_FALL);
    DL_GPIO_clearInterruptStatus(KEY2_PORT, KEY2_PIN);
    DL_GPIO_enableInterrupt(KEY2_PORT, KEY2_PIN);

    /*
     * TIMG6 去抖定时器: 单次模式, 20ms
     *   - 复位并上电
     *   - 时钟: BUSCLK, prescale=79 → 1MHz
     *   - One-shot: 从 19999 减到 0 触发 ZERO 中断
     *   - 初始不启动, 等按键中断触发后由软件启动
     */
    DL_Timer_reset(TIMG6);
    DL_Timer_enablePower(TIMG6);

    DL_Timer_ClockConfig clk_cfg = {
        .clockSel    = DL_TIMER_CLOCK_BUSCLK,
        .divideRatio = DL_TIMER_CLOCK_DIVIDE_1,
        .prescale    = TIMG6_PRESCALE,
    };
    DL_Timer_setClockConfig(TIMG6, &clk_cfg);

    DL_Timer_TimerConfig timer_cfg = {
        .timerMode    = DL_TIMER_TIMER_MODE_ONE_SHOT,
        .period       = TIMG6_PERIOD_TICKS,
        .startTimer   = DL_TIMER_STOP,
        .genIntermInt = DL_TIMER_INTERM_INT_DISABLED,
        .counterVal   = 0,
    };
    DL_Timer_initTimerMode(TIMG6, &timer_cfg);

    DL_Timer_enableInterrupt(TIMG6,
        DL_TIMER_INTERRUPT_ZERO_EVENT);
    NVIC_EnableIRQ(TIMG6_INT_IRQn);
}

/*
 * bsp_key_gpio_isr — 按键 GPIO 中断处理
 *   由 GROUP1_IRQHandler 在检测到按键引脚中断后调用.
 *   执行时间 < 1us, 仅关闭中断 + 启动定时器.
 */
void bsp_key_gpio_isr(uint32_t status)
{
    if (status & KEY1_PIN) {
        DL_GPIO_disableInterrupt(KEY1_PORT, KEY1_PIN);
        g_key_debounce_pending |= 0x01;
    }
    if (status & KEY2_PIN) {
        DL_GPIO_disableInterrupt(KEY2_PORT, KEY2_PIN);
        g_key_debounce_pending |= 0x02;
    }

    /* 启动/重启 20ms 去抖: 停止 → 写加载值 → 启动 */
    DL_Timer_stopCounter(TIMG6);
    DL_Timer_setLoadValue(TIMG6, TIMG6_PERIOD_TICKS);
    DL_Timer_startCounter(TIMG6);
}

/*
 * TIMG6_IRQHandler — 去抖定时器中断
 *   20ms 到期后读取按键电平, 确认或丢弃按下事件.
 */
void TIMG6_IRQHandler(void)
{
    uint32_t timer_status = DL_Timer_getRawInterruptStatus(TIMG6,
        DL_TIMER_INTERRUPT_ZERO_EVENT);

    if (timer_status & DL_TIMER_INTERRUPT_ZERO_EVENT) {
        /* KEY1 去抖检查 */
        if (g_key_debounce_pending & 0x01) {
            if (DL_GPIO_readPins(KEY1_PORT, KEY1_PIN) == 0) {
                /* 20ms 后仍为低 → 有效按下 */
                g_key1.state         = KEY_STATE_PRESSED;
                g_key1.hold_duration = 0;
                g_key1.press_count++;
            }
            /* 否则为抖动, 保持原 state */
            DL_GPIO_clearInterruptStatus(KEY1_PORT, KEY1_PIN);
            DL_GPIO_enableInterrupt(KEY1_PORT, KEY1_PIN);
            g_key_debounce_pending &= ~0x01;
        }

        /* KEY2 去抖检查 */
        if (g_key_debounce_pending & 0x02) {
            if (DL_GPIO_readPins(KEY2_PORT, KEY2_PIN) == 0) {
                g_key2.state         = KEY_STATE_PRESSED;
                g_key2.hold_duration = 0;
                g_key2.press_count++;
            }
            DL_GPIO_clearInterruptStatus(KEY2_PORT, KEY2_PIN);
            DL_GPIO_enableInterrupt(KEY2_PORT, KEY2_PIN);
            g_key_debounce_pending &= ~0x02;
        }
    }

    DL_Timer_clearInterruptStatus(TIMG6,
        DL_TIMER_INTERRUPT_ZERO_EVENT);
}

/*
 * bsp_key_update — 按键状态机周期刷新
 *   调用频率: 100Hz (10ms 间隔)
 *   功能:
 *     1. 轮询检测释放 (state=PRESSED 时读 GPIO)
 *     2. 长按计时 (hold_duration 累加, >= 1000ms → LONG)
 *     3. 短按/长按状态保持, 由应用层读取后手动清除
 */
void bsp_key_update(void)
{
    /* KEY1 状态刷新 */
    switch (g_key1.state) {
    case KEY_STATE_PRESSED:
        g_key1.hold_duration += 10;
        if (DL_GPIO_readPins(KEY1_PORT, KEY1_PIN) != 0) {
            /* 按键已释放 */
            if (g_key1.hold_duration >= KEY_LONG_PRESS_MS) {
                g_key1.state = KEY_STATE_LONG;
            } else {
                g_key1.state = KEY_STATE_SHORT;
            }
        } else if (g_key1.hold_duration >= KEY_LONG_PRESS_MS) {
            g_key1.state = KEY_STATE_LONG;
        }
        break;
    case KEY_STATE_SHORT:
    case KEY_STATE_LONG:
        /* 应用层读取后应手动清除为 RELEASED, 此处不自动复位 */
        break;
    default:
        break;
    }

    /* KEY2 状态刷新 (同上) */
    switch (g_key2.state) {
    case KEY_STATE_PRESSED:
        g_key2.hold_duration += 10;
        if (DL_GPIO_readPins(KEY2_PORT, KEY2_PIN) != 0) {
            if (g_key2.hold_duration >= KEY_LONG_PRESS_MS) {
                g_key2.state = KEY_STATE_LONG;
            } else {
                g_key2.state = KEY_STATE_SHORT;
            }
        } else if (g_key2.hold_duration >= KEY_LONG_PRESS_MS) {
            g_key2.state = KEY_STATE_LONG;
        }
        break;
    case KEY_STATE_SHORT:
    case KEY_STATE_LONG:
        break;
    default:
        break;
    }
}

bool bsp_key1_is_pressed(void)
{
    return (g_key1.state == KEY_STATE_PRESSED);
}

bool bsp_key2_is_pressed(void)
{
    return (g_key2.state == KEY_STATE_PRESSED);
}

uint8_t bsp_key1_get_state(void)
{
    return g_key1.state;
}

uint8_t bsp_key2_get_state(void)
{
    return g_key2.state;
}
