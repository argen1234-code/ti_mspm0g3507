#ifndef BSP_YABO_IMU_H
#define BSP_YABO_IMU_H

#include <stdint.h>

/* ---- WitMotion 串口协议定义 ----
 *
 * 数据帧类型 (pkt[3]):
 *   RAW   (0x04, 23B): 加速度 + 陀螺 + 磁力 (int16→float)
 *   EULER (0x26, 17B): 欧拉角 roll/pitch/yaw (IEEE754 float, rad→deg)
 *   QUAT  (0x16, 21B): 四元数 w/x/y/z (IEEE754 float) — 当前IMU无此传感器
 *   BARO  (0x32, 21B): 气压/高度/温度 (IEEE754 float) — 当前IMU无此传感器
 *
 * 数据流向: UART1 → imu_rx_buf[] → uart_imu_rxbuf_pop() → imu_yabo_process()
 */
#define IMU_SYNC_BYTE   0x7E
#define IMU_DEV_ADDR    0x23
#define IMU_PACKET_SIZE 23   /* 最大帧长, 仅用于缓冲区大小 */

/* ---- 数据类型 (pkt[3]) ---- */
#define IMU_TYPE_RAW    0x04
#define IMU_TYPE_EULER  0x26
#define IMU_TYPE_QUAT   0x16
#define IMU_TYPE_BARO   0x32

/* ---- IMU 数据结构 ---- */
typedef struct {
    float accel[3];   /* g */
    float gyro[3];    /* deg/s */
    float mag[3];     /* uT */
    float roll;       /* deg */
    float pitch;      /* deg */
    float yaw;        /* deg */
    float quat[4];
    float baro_alt;
    float baro_temp;
    float baro_pressure;
    float baro_pressure_ref;
} imu_yabo_data_t;

void imu_yabo_init(imu_yabo_data_t *imu);
void imu_yabo_process(imu_yabo_data_t *imu);

#endif
