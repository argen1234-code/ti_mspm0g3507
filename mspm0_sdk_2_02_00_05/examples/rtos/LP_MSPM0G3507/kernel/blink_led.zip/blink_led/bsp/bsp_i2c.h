/*
 * I2C 主机驱动 — I2C1 初始化 (预留)
 *
 * 数据流:
 *   上位机/传感器 ──→ I2C1 SCL/SDA ──→ DL_I2C API ──→ 上层协议解析
 *   典型用途: OLED (12864), 温湿度/气压/IMU 传感器, EEPROM
 *
 * 引脚:
 *   I2C1 SCL: PA29 (PINCM4)
 *   I2C1 SDA: PA30 (PINCM5)
 *
 *   I2C0 不可用 — 所有 SCL/SDA 引脚与已有外设冲突
 *   (PA0/PA1/PA10/PA11/PA28/PA31 已被 LED/伺服/UART0/编码器占用)
 *
 *   默认: 主机模式, 标准模式 100kHz, 7-bit 地址
 */

#ifndef BSP_I2C_H
#define BSP_I2C_H

#include <stdint.h>
#include <stdbool.h>

/* ---- I2C1 实例 ---- */
#define BSP_I2C_INST        I2C1
#define BSP_I2C_INT_IRQN    I2C1_INT_IRQn

/* ---- 引脚 ---- */
#define BSP_I2C_SCL_PORT    GPIOA
#define BSP_I2C_SCL_PIN     DL_GPIO_PIN_29
#define BSP_I2C_SCL_IOMUX   (IOMUX_PINCM4)
#define BSP_I2C_SDA_PORT    GPIOA
#define BSP_I2C_SDA_PIN     DL_GPIO_PIN_30
#define BSP_I2C_SDA_IOMUX   (IOMUX_PINCM5)

/*
 * bsp_i2c_init — 初始化 I2C1 主机
 *   1. 电源使能 + 复位
 *   2. GPIO 配置为 I2C 开漏外设功能
 *   3. 时钟配置: BUSCLK, 100kHz (标准模式)
 *   4. 使能 I2C 模块, 暂不使能中断 (上层按需开启)
 */
void bsp_i2c_init(void);

/* ---- 预留 API (待实现) ---- */

/*
 * bsp_i2c_write — 主机写数据到从机
 *   addr: 7-bit 从机地址
 *   data: 数据缓冲
 *   len:  数据长度
 *   return: true=成功 (收到 ACK), false=失败 (NACK/总线错误)
 */
bool bsp_i2c_write(uint8_t addr, const uint8_t *data, uint8_t len);

/*
 * bsp_i2c_read — 主机从从机读数据
 *   发送起始条件 → 写从机地址(R) → 读 len 字节 → 发送停止条件
 *   return: true=成功, false=失败
 */
bool bsp_i2c_read(uint8_t addr, uint8_t *data, uint8_t len);

/*
 * bsp_i2c_write_reg — 写从机寄存器
 *   发送: START → 从机地址(W) → reg → value → STOP
 */
bool bsp_i2c_write_reg(uint8_t addr, uint8_t reg, uint8_t value);

/*
 * bsp_i2c_read_reg — 读从机寄存器
 *   发送: START → 从机地址(W) → reg → RESTART → 从机地址(R) → 读1字节 → STOP
 */
bool bsp_i2c_read_reg(uint8_t addr, uint8_t reg, uint8_t *value);

/*
 * bsp_i2c_scan — 扫描 I2C 总线, 打印所有响应 ACK 的从机地址 (调试用)
 */
void bsp_i2c_scan(void);

#endif
