/*
 * 四路舵机 PWM 驱动 — TIMA0 边沿对齐
 *
 * 数据流:
 *   app → bsp_servo_set_pulse(ch, us) → TIMA0 CCP→ 舵机
 *   app → bsp_servo_set_angle(ch, deg) → 角度→脉宽转换 → TIMA0 CCP→ 舵机
 *
 * 硬件:
 *   TIMA0 (80MHz BUSCLK), 4路CCP独立占空比, 边沿对齐模式
 *   CH0: PB8  (IOMUX_PINCM25, PF=4)
 *   CH1: PA1  (IOMUX_PINCM2,  PF=4)
 *   CH2: PB0  (IOMUX_PINCM12, PF=5)
 *   CH3: PA28 (IOMUX_PINCM3,  PF=4)
 *
 * 舵机 PWM 典型参数 (可通过修改宏定义调整):
 *   频率:      50 Hz     (周期 20ms)
 *   脉宽范围:  500~2500 us  (对应 0°~180°)
 *   中立点:    1500 us      (对应 90°)
 *   死区:      脉宽 < MIN_PULSE 或 > MAX_PULSE 时输出关断 (可选)
 *
 * 时钟计算 (80MHz BUSCLK):
 *   prescale=63 → timerClk = 80MHz/(63+1) = 1.25MHz → tick = 0.8us
 *   period    = 20ms / 0.8us = 25000
 *   500us     = 500/0.8  = 625 tick
 *   1500us    = 1500/0.8 = 1875 tick
 *   2500us    = 2500/0.8 = 3125 tick
 *
 * 频率/脉宽范围待定 — 当前使用典型值, 后续根据实际舵机型号调整
 */

#ifndef BSP_SERVO_H
#define BSP_SERVO_H

#include <stdint.h>
#include <stdbool.h>
#include "ti_msp_dl_config.h"

/* ---- 硬件引脚 ---- */
#define SERVO_PORT_CH0       GPIOB
#define SERVO_PIN_CH0        DL_GPIO_PIN_8
#define SERVO_IOMUX_CH0      (IOMUX_PINCM25)
#define SERVO_IOMUX_FUNC_CH0 IOMUX_PINCM25_PF_TIMA0_CCP0

#define SERVO_PORT_CH1       GPIOA
#define SERVO_PIN_CH1        DL_GPIO_PIN_1
#define SERVO_IOMUX_CH1      (IOMUX_PINCM2)
#define SERVO_IOMUX_FUNC_CH1 IOMUX_PINCM2_PF_TIMA0_CCP1

#define SERVO_PORT_CH2       GPIOB
#define SERVO_PIN_CH2        DL_GPIO_PIN_0
#define SERVO_IOMUX_CH2      (IOMUX_PINCM12)
#define SERVO_IOMUX_FUNC_CH2 IOMUX_PINCM12_PF_TIMA0_CCP2

#define SERVO_PORT_CH3       GPIOA
#define SERVO_PIN_CH3        DL_GPIO_PIN_28
#define SERVO_IOMUX_CH3      (IOMUX_PINCM3)
#define SERVO_IOMUX_FUNC_CH3 IOMUX_PINCM3_PF_TIMA0_CCP3

/* ---- TIMA0 实例 ---- */
#define SERVO_TIMER_INST     TIMA0

/* ---- PWM 参数 (可通过修改这些宏适配不同舵机) ---- */
#define SERVO_TIMER_CLK_HZ   80000000UL   /* BUSCLK */
#define SERVO_PRESCALE       63U          /* 分频系数: 80MHz/(63+1)=1.25MHz */
#define SERVO_TICK_HZ        1250000UL    /* 分频后时钟: 1.25MHz */
#define SERVO_TICK_US        0.8f         /* 每tick微秒数 */

#define SERVO_FREQ_HZ        50U          /* PWM 频率 */
#define SERVO_PERIOD_TICK    25000U       /* 周期: SERVO_TICK_HZ/SERVO_FREQ = 25000 */

#define SERVO_MIN_PULSE_US   500U         /* 最小脉宽 (0°), us */
#define SERVO_MAX_PULSE_US   2500U        /* 最大脉宽 (180°), us */
#define SERVO_MIN_PULSE_TICK 625U         /* 最小脉宽: 500/0.8 = 625 */
#define SERVO_MAX_PULSE_TICK 3125U        /* 最大脉宽: 2500/0.8 = 3125 */

/* ---- API ---- */

void bsp_servo_init(void);

/*
 * bsp_servo_set_pulse — 设置指定通道的脉宽 (微秒)
 *   ch: 通道号 0~3
 *   pulse_us: 脉宽, 单位微秒, 超出 [SERVO_MIN_PULSE_US, SERVO_MAX_PULSE_US] 将钳位
 */
void bsp_servo_set_pulse(uint8_t ch, uint16_t pulse_us);

/*
 * bsp_servo_set_angle — 设置指定通道的角度
 *   ch:  通道号 0~3
 *   deg: 角度 0~180, 线性映射到脉宽 [MIN_PULSE, MAX_PULSE]
 */
void bsp_servo_set_angle(uint8_t ch, uint8_t deg);

#endif
