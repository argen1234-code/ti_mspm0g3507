/*
 * 四路直流电机驱动 — 双 TB6612 H桥
 *
 * TB6612 #1 (在用):
 *   Motor A: PA14(AIN1)/PA15(AIN2) 方向 + PB2(TIMA1 CCP0) PWM
 *   Motor B: PA17(BIN1)/PA16(BIN2) 方向 + PB3(TIMA1 CCP1) PWM
 *
 * TB6612 #2 (预留, 已初始化):
 *   Motor C: PA9(C_AIN1)/PA19(C_AIN2) 方向 + PA3(TIMG7 CCP0) PWM
 *   Motor D: PA20(D_BIN1)/PB1(D_BIN2) 方向 + PA23(TIMG8 CCP0) PWM
 *   STBY:   PB27 (共用使能, 高有效)
 */

#ifndef BSP_MOTOR_H
#define BSP_MOTOR_H

#include <stdint.h>

/* ---- 电机 A/B (TIMA1, 在用) ---- */
int32_t bsp_motor_velocity_A(int32_t target, int32_t current);
int32_t bsp_motor_velocity_B(int32_t target, int32_t current);
void    bsp_motor_set_pwm(int32_t pwma, int32_t pwmb);
int32_t bsp_motor_limit_pwm(int32_t value, int32_t low, int32_t high);

/* ---- 电机 C/D (TIMG7/TIMG8, 预留) ---- */
void bsp_motor_init_cd(void);
void bsp_motor_set_pwm_cd(int32_t pwmC, int32_t pwmD);

#endif
