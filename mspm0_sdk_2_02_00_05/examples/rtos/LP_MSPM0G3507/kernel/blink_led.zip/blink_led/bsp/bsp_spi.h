/*
 * SPI 主机驱动 — SPI0 + SPI1 初始化 (预留)
 *
 * 数据流:
 *   外设芯片 ──→ SPIx SCLK/PICO/POCI/CS ──→ DL_SPI API ──→ 上层协议
 *   典型用途: OLED (SPI 接口), Flash, SD 卡, 高速 ADC/DAC, 无线模块
 *
 * 引脚:
 *   SPI0: PA6(SCLK) + PA5(PICO) + PA4(POCI) + PA2(CS0)
 *         PINCM11/10/9/7, 全部在 GPIOA
 *
 *   SPI1: PB16(SCLK) + PB15(PICO) + PB14(POCI)
 *         PINCM33/32/31, 全部在 GPIOB, 三个引脚相邻
 *         CS 使用 GPIO 软件片选 (硬件 CS 引脚与已用外设冲突)
 *
 *   默认: 主机模式, CPOL=0 CPHA=0, 1MHz, 8-bit 帧, MSB first
 *   中断/TX FIFO 暂不使能, 上层按需开启
 */

#ifndef BSP_SPI_H
#define BSP_SPI_H

#include <stdint.h>
#include <stdbool.h>

/* ======================== SPI0 ======================== */
#define BSP_SPI0_INST       SPI0
#define BSP_SPI0_INT_IRQN   SPI0_INT_IRQn

#define BSP_SPI0_SCLK_PORT  GPIOA
#define BSP_SPI0_SCLK_PIN   DL_GPIO_PIN_6
#define BSP_SPI0_SCLK_IOMUX (IOMUX_PINCM11)

#define BSP_SPI0_PICO_PORT  GPIOA
#define BSP_SPI0_PICO_PIN   DL_GPIO_PIN_5
#define BSP_SPI0_PICO_IOMUX (IOMUX_PINCM10)

#define BSP_SPI0_POCI_PORT  GPIOA
#define BSP_SPI0_POCI_PIN   DL_GPIO_PIN_4
#define BSP_SPI0_POCI_IOMUX (IOMUX_PINCM9)

#define BSP_SPI0_CS0_PORT   GPIOA
#define BSP_SPI0_CS0_PIN    DL_GPIO_PIN_2
#define BSP_SPI0_CS0_IOMUX  (IOMUX_PINCM7)

/* ======================== SPI1 ======================== */
#define BSP_SPI1_INST       SPI1
#define BSP_SPI1_INT_IRQN   SPI1_INT_IRQn

#define BSP_SPI1_SCLK_PORT  GPIOB
#define BSP_SPI1_SCLK_PIN   DL_GPIO_PIN_16
#define BSP_SPI1_SCLK_IOMUX (IOMUX_PINCM33)

#define BSP_SPI1_PICO_PORT  GPIOB
#define BSP_SPI1_PICO_PIN   DL_GPIO_PIN_15
#define BSP_SPI1_PICO_IOMUX (IOMUX_PINCM32)

#define BSP_SPI1_POCI_PORT  GPIOB
#define BSP_SPI1_POCI_PIN   DL_GPIO_PIN_14
#define BSP_SPI1_POCI_IOMUX (IOMUX_PINCM31)

/* ---- API ---- */

void bsp_spi_init(void);   /* 初始化 SPI0 + SPI1 */

/* ---- 预留 API (待实现) ---- */

/*
 * bsp_spi0_transfer — SPI0 全双工传输 (阻塞)
 *   tx: 发送缓冲 (可为 NULL, 此时发送 0x00)
 *   rx: 接收缓冲 (可为 NULL, 此时丢弃接收数据)
 *   len: 字节数
 *   同时操作 CS0 (PA2) 硬件片选
 */
bool bsp_spi0_transfer(const uint8_t *tx, uint8_t *rx, uint8_t len);

/*
 * bsp_spi1_transfer — SPI1 全双工传输 (阻塞)
 *   cs_pin: 软件片选 GPIO pin (由调用方指定, 如不指定则传 0)
 */
bool bsp_spi1_transfer(const uint8_t *tx, uint8_t *rx, uint8_t len, uint32_t cs_pin);

/*
 * bsp_spi0_set_freq — 调整 SPI0 时钟频率 (Hz)
 *   freq_hz: 目标频率, 实际会取 BUSCLK 分频后的最接近值
 */
void bsp_spi0_set_freq(uint32_t freq_hz);
void bsp_spi1_set_freq(uint32_t freq_hz);

#endif
