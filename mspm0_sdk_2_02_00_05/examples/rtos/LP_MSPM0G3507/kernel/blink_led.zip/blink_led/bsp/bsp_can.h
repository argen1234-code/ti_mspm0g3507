/*
 * CAN-FD 通信接口 — 预留
 *
 * 数据流 (未来):
 *   上位机 ──CANFD0──→ CAN_RX (PA13) ──→ MCAN0 FIFO ──→ bsp_can_read()
 *   bsp_can_send() ──→ MCAN0 TX Buff ──→ CAN_TX (PA12) ──CANFD0──→ 上位机
 *
 * 硬件: MSPM0G3507 MCAN0 (CANFD0), 需外部 CAN 收发器 (如 SN65HVD230)
 * 当前状态: 引脚已配置, MCAN 内部回环模式 (自收发), 无应用层代码
 *
 * 引脚: PA12 (CAN_TX) / PA13 (CAN_RX) — 由 SysConfig 配置
 */

#ifndef BSP_CAN_H
#define BSP_CAN_H

#include <stdint.h>
#include <stdbool.h>
#include "ti_msp_dl_config.h"

/* ---- CAN 消息结构 ---- */
typedef struct {
    uint32_t id;          /* 标准帧: 11-bit ID, 扩展帧: 29-bit ID */
    uint8_t  data[64];    /* CAN-FD 最大 64 字节 */
    uint8_t  dlc;         /* 数据长度 (0-8/12/16/20/24/32/48/64) */
    bool     is_ext;      /* true = 扩展帧, false = 标准帧 */
    bool     is_fd;       /* true = CAN-FD, false = 经典 CAN */
    bool     is_rtr;      /* 远程帧 */
} bsp_can_msg_t;

/* ---- 外部接口 (当前均为空实现) ---- */

void bsp_can_init(void);                               /* CAN 模块初始化 (SysConfig 已做) */
void bsp_can_send(const bsp_can_msg_t *msg);           /* 发送 CAN 消息 */
bool bsp_can_read(bsp_can_msg_t *msg);                 /* 读取 CAN 消息 (非阻塞) */
void bsp_can_set_filter(uint32_t id, uint32_t mask);   /* 设置硬件接收过滤 */

#endif
