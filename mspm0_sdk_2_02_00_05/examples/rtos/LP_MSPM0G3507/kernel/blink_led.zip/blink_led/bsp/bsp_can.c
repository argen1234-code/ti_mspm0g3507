/*
 * CAN-FD 通信驱动
 *
 * 数据流 (未来实现):
 *   TX: 应用层 → bsp_can_send() → DL_MCAN_writeMsgRam() → CAN_TX → 收发器 → CAN 总线
 *   RX: CAN 总线 → 收发器 → CAN_RX → MCAN0 RX FIFO
 *       → bsp_can_read() → DL_MCAN_readMsgRam() → 应用层
 *
 * 当前状态: MCAN0 已在 ti_msp_dl_config.c 中初始化为内部回环模式,
 * 本文件仅提供接口桩函数, 等待应用层需求后实现。
 */

#include "bsp_can.h"
#include "ti_msp_dl_config.h"

void bsp_can_init(void)
{
    /* MCAN0 初始化已在 SYSCFG_DL_MCAN0_init() 中完成 (ti_msp_dl_config.c)
     * 此处保留以支持将来额外的应用层配置 (如自定义过滤、速率切换) */
}

void bsp_can_send(const bsp_can_msg_t *msg)
{
    (void)msg;
    /* TODO: DL_MCAN_writeMsgRam(MCAN0_INST, txBufIdx, ...) */
}

bool bsp_can_read(bsp_can_msg_t *msg)
{
    (void)msg;
    /* TODO: DL_MCAN_readMsgRam(MCAN0_INST, DL_MCAN_FIFO_0, ...) */
    return false;
}

void bsp_can_set_filter(uint32_t id, uint32_t mask)
{
    (void)id;
    (void)mask;
    /* TODO: DL_MCAN_addStdMsgIDFilter() at runtime */
}
