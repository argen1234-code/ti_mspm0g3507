/*
 * WitMotion 串口 IMU 协议解析
 *
 * 数据流向:
 *   IMU 硬件 ──UART1──→ UART1_IRQHandler ──→ imu_rx_buf[] (环形缓冲, bsp_uart.c)
 *     → uart_imu_rxbuf_pop() ← 本模块消费者
 *     → 状态机 S_SYNC → S_BODY → dispatch_packet() → imu_yabo_data_t
 *
 *   当前 IMU 型号输出两种帧:
 *     RAW (0x04, 23B): 加速度(g) + 陀螺(deg/s) + 磁力(uT)
 *     EULER (0x26, 17B): 欧拉角 roll/pitch/yaw (rad → deg 转换)
 *
 *   未使用的协议帧 (IMU 无对应传感器):
 *     QUAT (0x16, 21B): 四元数
 *     BARO (0x32, 21B): 气压/高度/温度
 *
 * 帧格式 (可变长, pkt[2] 指定总长度):
 *   [0] SYNC 0x7E  [1] DEV_ADDR 0x23  [2] LEN  [3] TYPE
 *   [4..LEN-2] payload (IEEE754 float 或 int16, 小端)
 *   [LEN-1] checksum = SUM[0..LEN-2]
 *
 * 引脚: PB4 (UART1 TX, 未使用) / PB5 (UART1 RX)
 */

#include "bsp_yabo_IMU.h"
#include "bsp_uart.h"
#include <string.h>

#define RAD2DEG       57.2957795f
#define GYRO_SCALE    (1000.0f / 32767.0f)   /* 量程 ±1000 deg/s */

/* ---- 小端 int16 ---- */
static int16_t to_int16(const uint8_t *p)
{
    return (int16_t)(((uint16_t)p[1] << 8) | p[0]);
}

/* ---- IEEE754 float ---- */
static float to_float(const uint8_t *p)
{
    float f;
    uint32_t u = (uint32_t)p[0] | ((uint32_t)p[1] << 8)
               | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
    memcpy(&f, &u, sizeof(f));
    return f;
}

/* ---- 校验: SUM[0..len-2] == pkt[len-1] ---- */
static uint8_t calc_checksum(const uint8_t *pkt, uint8_t len)
{
    uint8_t sum = 0;
    for (uint8_t i = 0; i < len - 1; i++) {
        sum += pkt[i];
    }
    return sum;
}

/* ---- 数据分发 ---- */
static void dispatch_packet(const uint8_t *pkt, imu_yabo_data_t *imu)
{
    uint8_t type = pkt[3];

    if (type == IMU_TYPE_RAW) {
        imu->accel[0] = to_int16(&pkt[4])  * (16.0f / 32767.0f);
        imu->accel[1] = to_int16(&pkt[6])  * (16.0f / 32767.0f);
        imu->accel[2] = to_int16(&pkt[8])  * (16.0f / 32767.0f);

        imu->gyro[0]  = to_int16(&pkt[10]) * GYRO_SCALE;
        imu->gyro[1]  = to_int16(&pkt[12]) * GYRO_SCALE;
        imu->gyro[2]  = to_int16(&pkt[14]) * GYRO_SCALE;

        imu->mag[0]   = to_int16(&pkt[16]) * (800.0f / 32767.0f);
        imu->mag[1]   = to_int16(&pkt[18]) * (800.0f / 32767.0f);
        imu->mag[2]   = to_int16(&pkt[20]) * (800.0f / 32767.0f);
    }
    else if (type == IMU_TYPE_EULER) {
        imu->roll  = to_float(&pkt[4])  * RAD2DEG;
        imu->pitch = to_float(&pkt[8])  * RAD2DEG;
        imu->yaw   = to_float(&pkt[12]) * RAD2DEG;
    }
    else if (type == IMU_TYPE_QUAT) {
        imu->quat[0] = to_float(&pkt[4]);
        imu->quat[1] = to_float(&pkt[8]);
        imu->quat[2] = to_float(&pkt[12]);
        imu->quat[3] = to_float(&pkt[16]);
    }
    else if (type == IMU_TYPE_BARO) {
        imu->baro_alt           = to_float(&pkt[4]);
        imu->baro_temp          = to_float(&pkt[8]);
        imu->baro_pressure      = to_float(&pkt[12]);
        imu->baro_pressure_ref  = to_float(&pkt[16]);
    }
}

/* ---- 初始化 ---- */
void imu_yabo_init(imu_yabo_data_t *imu)
{
    memset(imu, 0, sizeof(*imu));
}

/* ---- 从环形缓冲取字节, 解析帧 (可变长: pkt[2]=帧长度) ---- */
void imu_yabo_process(imu_yabo_data_t *imu)
{
    enum { S_SYNC = 0, S_BODY };
    static uint8_t state = S_SYNC;
    static uint8_t pkt[IMU_PACKET_SIZE];
    static uint8_t idx  = 0;

    uint8_t byte;
    while (uart_imu_rxbuf_pop(&byte)) {
        switch (state) {
        case S_SYNC:
            if (byte == IMU_SYNC_BYTE) {
                pkt[0] = byte;
                idx = 1;
                state = S_BODY;
            }
            break;

        case S_BODY: {
            pkt[idx++] = byte;

            /* 收到长度字段 (pkt[2]) 后, 校验合法范围 */
            uint8_t frame_len = 0;
            if (idx >= 3) {
                frame_len = pkt[2];
                if (frame_len < 5 || frame_len > IMU_PACKET_SIZE) {
                    state = S_SYNC;  /* 非法帧长, 重新同步 */
                    break;
                }
            } else {
                break;  /* 还没收到长度字段 */
            }

            if (idx >= frame_len) {
                state = S_SYNC;
                if (pkt[1] == IMU_DEV_ADDR
                    && calc_checksum(pkt, frame_len) == pkt[frame_len - 1]) {
                    dispatch_packet(pkt, imu);
                }
            }
            break;
        }

        default:
            state = S_SYNC;
            break;
        }
    }
}
