/*
 * 两路按键驱动 — GPIO 下降沿中断 + TIMG6 硬件去抖
 *
 * 数据流:
 *   KEY1 (PA18) ─┐
 *                ├─→ GPIOA 下降沿中断 → bsp_key_gpio_isr()
 *   KEY2 (PA24) ─┘      │
 *                       ├─ 关闭按键中断 (防抖期间忽略新边沿)
 *                       └─ 启动 TIMG6 单次 20ms
 *                            │
 *                            ▼ TIMG6_ZERO_IRQHandler
 *                              ├─ 读取按键电平 (稳定态)
 *                              ├─ 仍为低 → 有效按下 → 更新 key_dev_t
 *                              ├─ 已恢复 → 抖动 → 丢弃
 *                              └─ 重新使能按键中断
 *
 *   bsp_key_update() 周期性调用 (100Hz):
 *     ├─ 检查长按 (>1000ms)
 *     └─ 管理 press_count / state
 *
 * 按键中断复用 GPIOA_INT → GROUP1_IRQHandler (与编码器共享)
 */

#ifndef BSP_KEY_H
#define BSP_KEY_H

#include <stdint.h>
#include <stdbool.h>

/* ---- KEY1: PA18 (SysConfig GPIO2 已配为数字输入, 低有效) ---- */
#define KEY1_PORT       GPIOA
#define KEY1_PIN        DL_GPIO_PIN_18
#define KEY1_IOMUX      (IOMUX_PINCM40)

/* ---- KEY2: PA24 (低有效) ---- */
#define KEY2_PORT       GPIOA
#define KEY2_PIN        DL_GPIO_PIN_24
#define KEY2_IOMUX      (IOMUX_PINCM54)

/* ---- 去抖/长按阈值 ---- */
#define KEY_DEBOUNCE_MS     20U
#define KEY_LONG_PRESS_MS    1000U

/* ---- 按键状态 ---- */
#define KEY_STATE_RELEASED  0
#define KEY_STATE_PRESSED   1   /* 已确认按下 (hold 中) */
#define KEY_STATE_SHORT     2   /* 短按释放 (hold < 1s) */
#define KEY_STATE_LONG      3   /* 长按触发 (hold >= 1s) */

typedef struct {
    uint8_t  state;          /* KEY_STATE_xxx */
    uint32_t press_time;     /* 去抖确认时刻 (bsp_key_update 调用次数, 10ms/次) */
    uint32_t hold_duration;  /* 当前已按住时长 (ticks) */
    uint32_t press_count;    /* 累计有效按下次数 (自初始化起) */
} key_dev_t;

extern key_dev_t g_key1;
extern key_dev_t g_key2;

/* ---- API ---- */

/*
 * bsp_key_init — 初始化两路按键 + TIMG6 去抖
 *   1. KEY1/KEY2 GPIO 数字输入 + 上拉 + 下降沿中断
 *   2. TIMG6 单次模式, 20ms 去抖周期
 *   3. NVIC 使能 (GPIOA + TIMG6 已在 bsp_encoder_init 使能, 此处无操作)
 */
void bsp_key_init(void);

/*
 * bsp_key_gpio_isr — 按键 GPIO 中断处理 (由 GROUP1_IRQHandler 调用)
 *   status: DL_GPIO_getEnabledInterruptStatus 的返回值
 *   去抖策略: 关闭触发中断的按键中断 → 启动 TIMG6 20ms → 结束后重读电平
 */
void bsp_key_gpio_isr(uint32_t status);

/*
 * bsp_key_update — 按键状态机周期更新 (10ms 周期)
 *   管理长按计时、短按→已读自动清除等
 */
void bsp_key_update(void);

bool    bsp_key1_is_pressed(void);
bool    bsp_key2_is_pressed(void);
uint8_t bsp_key1_get_state(void);
uint8_t bsp_key2_get_state(void);

#endif
