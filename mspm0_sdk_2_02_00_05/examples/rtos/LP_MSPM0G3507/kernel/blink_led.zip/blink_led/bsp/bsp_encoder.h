#ifndef BSP_ENCODER_H
#define BSP_ENCODER_H

#include <stdint.h>

/*
 * 四路正交编码器驱动 — GPIO 中断 + 二倍频计数
 *
 * 数据流向:
 *   电机旋转 → 编码器 A/B 相脉冲 → GPIO 边沿中断 (GROUP1_IRQHandler)
 *     Encoder A (左轮):     PA25(E1A) / PA26(E1B) → GPIOA_INT → g_encoderA_cnt
 *     Encoder B (右轮):     PB20(E2A) / PB24(E2B) → GPIOB_INT → g_encoderB_cnt
 *     Encoder C (预留):     PB6(E3A)  / PB7(E3B)   → GPIOB_INT → g_encoderC_cnt
 *     Encoder D (预留):     PA27(E4A) / PA31(E4B)  → GPIOA_INT → g_encoderD_cnt
 *
 *   编码器A/B: 100Hz 底盘任务读取 g_encoderA/B_cnt 计算转速 RPM
 *   编码器C/D: 硬件已使能, 计数运行中, 应用层暂未使用
 *
 * 四倍频: 13线 × 2(A+B相) × 2(上下沿) = 52 脉冲/转
 * 减速比: 30:1 → 52 × 30 = 1560 脉冲/输出轴转
 */

/* ---- 编码器参数 ---- */
#define ENCODER_LINES       13      /* 编码器线数 (每转脉冲数) */
#define MULTIPLY_FACTOR     2       /* 倍频因子 (A+B 两相) */
#define GEAR_RATIO          30      /* 电机减速比 */

/*
 * Encoder A/B (SysConfig 配置, 宏在 ti_msp_dl_config.h):
 *   Encoder A: PA25 (E1A, PINCM55) + PA26 (E1B, PINCM59)
 *   Encoder B: PB20 (E2A, PINCM48) + PB24 (E2B, PINCM52)
 */

/* ---- Encoder C (预留): PB6/PB7, GPIOB ---- */
#define ENCODERC_PORT       GPIOB
#define ENCODERC_E3A_PIN    DL_GPIO_PIN_6
#define ENCODERC_E3A_IOMUX  (IOMUX_PINCM23)
#define ENCODERC_E3B_PIN    DL_GPIO_PIN_7
#define ENCODERC_E3B_IOMUX  (IOMUX_PINCM24)

/* ---- Encoder D (预留): PA27/PA31, GPIOA ---- */
#define ENCODERD_PORT       GPIOA
#define ENCODERD_E4A_PIN    DL_GPIO_PIN_27
#define ENCODERD_E4A_IOMUX  (IOMUX_PINCM60)
#define ENCODERD_E4B_PIN    DL_GPIO_PIN_31
#define ENCODERD_E4B_IOMUX  (IOMUX_PINCM6)

/* ---- 全局计数 (volatile, ISR 写入, Task 读取) ---- */
extern volatile int32_t g_encoderA_cnt;
extern volatile int32_t g_encoderB_cnt;
extern volatile int32_t g_encoderC_cnt;
extern volatile int32_t g_encoderD_cnt;

void  bsp_encoder_init(void);
float bsp_encoder_calc_rpm(int32_t encoder_count, uint32_t sample_time_ms);

#endif
